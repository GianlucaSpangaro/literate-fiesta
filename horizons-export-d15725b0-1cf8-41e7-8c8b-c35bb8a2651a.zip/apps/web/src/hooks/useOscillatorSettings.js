
import { useState, useEffect, useCallback } from 'react';

const DEFAULTS = {
  rsi: { period: 14, overbought: 70, oversold: 30 },
  macd: { fastEMA: 12, slowEMA: 26, signalLine: 9 },
  bollingerBands: { period: 20, stdDev: 2 },
  sar: { accelerationFactor: 0.02, maxAccelerationFactor: 0.2 },
  ma200: { period: 200, type: 'SMA' }
};

const RANGES = {
  rsi: { 
    period: { min: 5, max: 50 }, 
    overbought: { min: 50, max: 90 }, 
    oversold: { min: 10, max: 50 } 
  },
  macd: { 
    fastEMA: { min: 5, max: 20 }, 
    slowEMA: { min: 20, max: 50 }, 
    signalLine: { min: 5, max: 15 } 
  },
  bollingerBands: { 
    period: { min: 10, max: 50 }, 
    stdDev: { min: 1, max: 3 } 
  },
  sar: { 
    accelerationFactor: { min: 0.01, max: 0.05 }, 
    maxAccelerationFactor: { min: 0.1, max: 0.5 } 
  },
  ma200: {
    period: { min: 50, max: 500 }
  }
};

export function useOscillatorSettings() {
  const [settings, setSettings] = useState(() => {
    try {
      const saved = localStorage.getItem('oscillatorSettings');
      if (saved) {
        const parsed = JSON.parse(saved);
        // Migration checks
        if (parsed.stochastic && !parsed.sar) {
          parsed.sar = DEFAULTS.sar;
          delete parsed.stochastic;
        }
        if (!parsed.ma200) {
          parsed.ma200 = DEFAULTS.ma200;
        }
        return { ...DEFAULTS, ...parsed };
      }
    } catch (e) {
      console.error('Failed to parse oscillator settings from localStorage', e);
    }
    return DEFAULTS;
  });

  const [appliedSettings, setAppliedSettings] = useState(settings);

  useEffect(() => {
    localStorage.setItem('oscillatorSettings', JSON.stringify(settings));
  }, [settings]);

  const validateRange = useCallback((oscillator, param, value) => {
    if (oscillator === 'ma200' && param === 'type') {
      return ['SMA', 'EMA'].includes(value) ? value : 'SMA';
    }

    const range = RANGES[oscillator][param];
    const numValue = Number(value);
    
    if (isNaN(numValue)) return range.min;
    if (numValue < range.min) return range.min;
    if (numValue > range.max) return range.max;
    
    // Ensure period is an integer for MA200
    if (oscillator === 'ma200' && param === 'period') {
      return Math.round(numValue);
    }
    
    return numValue;
  }, []);

  const updateSetting = useCallback((oscillator, param, value) => {
    setSettings(prev => ({
      ...prev,
      [oscillator]: {
        ...prev[oscillator],
        [param]: value
      }
    }));
  }, []);

  const resetOscillator = useCallback((oscillator) => {
    setSettings(prev => ({
      ...prev,
      [oscillator]: DEFAULTS[oscillator]
    }));
  }, []);

  const resetMA200ToDefaults = useCallback(() => {
    resetOscillator('ma200');
  }, [resetOscillator]);

  const applySettings = useCallback(() => {
    // Validate all settings before applying
    const validatedSettings = { ...settings };
    
    Object.keys(validatedSettings).forEach(oscillator => {
      Object.keys(validatedSettings[oscillator]).forEach(param => {
        validatedSettings[oscillator][param] = validateRange(
          oscillator, 
          param, 
          validatedSettings[oscillator][param]
        );
      });
    });

    // Special cross-parameter validation
    if (validatedSettings.rsi.overbought <= validatedSettings.rsi.oversold) {
      validatedSettings.rsi.overbought = 70;
      validatedSettings.rsi.oversold = 30;
    }
    if (validatedSettings.macd.fastEMA >= validatedSettings.macd.slowEMA) {
      validatedSettings.macd.fastEMA = 12;
      validatedSettings.macd.slowEMA = 26;
    }
    if (validatedSettings.sar.maxAccelerationFactor <= validatedSettings.sar.accelerationFactor) {
      validatedSettings.sar.maxAccelerationFactor = validatedSettings.sar.accelerationFactor + 0.1;
    }

    setSettings(validatedSettings);
    setAppliedSettings(validatedSettings);
    
    return validatedSettings;
  }, [settings, validateRange]);

  return {
    settings,
    appliedSettings,
    updateSetting,
    resetOscillator,
    resetMA200ToDefaults,
    applySettings,
    validateRange
  };
}
