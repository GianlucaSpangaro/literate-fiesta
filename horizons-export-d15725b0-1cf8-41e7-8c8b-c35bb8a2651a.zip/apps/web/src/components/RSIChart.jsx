
import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { format } from 'date-fns';

const RSIChart = ({ data }) => {
  const chartData = data?.map(item => ({
    timestamp: item.timestamp,
    rsi: item.value
  })) || [];

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || payload.length === 0) return null;

    const data = payload[0].payload;
    const date = new Date(data.timestamp);

    return (
      <div className="chart-tooltip">
        <div className="chart-tooltip-label">
          {format(date, 'MMM dd, yyyy HH:mm')}
        </div>
        <div className="chart-tooltip-item">
          <span>RSI:</span>
          <span className="chart-tooltip-value">{data.rsi?.toFixed(2)}</span>
        </div>
      </div>
    );
  };

  const formatXAxis = (timestamp) => {
    const date = new Date(timestamp);
    return format(date, 'MMM dd');
  };

  if (!chartData || chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-card rounded-xl border border-border">
        <p className="text-muted-foreground">No RSI data available</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <h3 className="text-lg font-semibold mb-4" style={{ letterSpacing: '-0.01em' }}>
        RSI (Relative Strength Index)
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <LineChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={formatXAxis}
            stroke="hsl(var(--muted-foreground))"
            style={{ fontSize: '0.75rem' }}
          />
          <YAxis
            domain={[0, 100]}
            stroke="hsl(var(--muted-foreground))"
            style={{ fontSize: '0.75rem' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            wrapperStyle={{ fontSize: '0.875rem' }}
            iconType="line"
          />
          <ReferenceLine
            y={70}
            stroke="hsl(var(--muted-foreground))"
            strokeDasharray="3 3"
            label={{ value: 'Overbought', position: 'right', fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
          />
          <ReferenceLine
            y={30}
            stroke="hsl(var(--muted-foreground))"
            strokeDasharray="3 3"
            label={{ value: 'Oversold', position: 'right', fill: 'hsl(var(--muted-foreground))', fontSize: 12 }}
          />
          <Line
            type="monotone"
            dataKey="rsi"
            stroke="hsl(var(--rsi))"
            strokeWidth={2}
            dot={false}
            name="RSI"
            connectNulls
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default RSIChart;
