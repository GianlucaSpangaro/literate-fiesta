
import React, { useMemo, useState, useRef, useEffect } from 'react';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { format } from 'date-fns';
import { ArrowUpDown, ArrowUp, ArrowDown, ArrowLeftRight, ArrowLeft, ArrowRight } from 'lucide-react';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const getCurrencySymbol = (symbol) => {
  if (!symbol) return '$';
  const upperSym = String(symbol).toUpperCase().trim();
  if (upperSym.includes('.MI')) return '€';
  if (upperSym.includes('.DE')) return '€';
  if (upperSym.includes('.PA')) return '€';
  if (upperSym.includes('.L')) return '£';
  return '$';
};

const CandlestickChart = ({ 
  data, 
  volumes, 
  ma200, 
  bollingerBands, 
  sar,
  volumeMA,
  rsi,
  macd,
  symbol = '',
  selectedPeriod = '1y',
  showMA200 = true,
  showBollinger = true,
  showSAR = true,
  showVolumeMA = false,
  setShowVolumeMA,
  volumeMAPeriod = 20,
  setVolumeMAPeriod,
  ma200Period = 200,
  ma200Type = 'SMA',
  isFullscreen = false
}) => {
  const containerRef = useRef(null);
  const chartAreaRef = useRef(null);

  const [viewState, setViewState] = useState({
    startIndex: 0,
    endIndex: 0,
    minPrice: 0,
    maxPrice: 100,
    isInitialized: false
  });

  const [dragState, setDragState] = useState({
    isDragging: false,
    startX: 0,
    startY: 0,
    initialStartIndex: 0,
    initialEndIndex: 0,
    initialMinPrice: 0,
    initialMaxPrice: 100
  });

  const [hoveredCandleIndex, setHoveredCandleIndex] = useState(null);
  const [mousePos, setMousePos] = useState({ x: null, y: null });
  const [hoveredPrice, setHoveredPrice] = useState(null);

  let activeSymbol = symbol;
  if (!activeSymbol && typeof window !== 'undefined') {
    activeSymbol = new URLSearchParams(window.location.search).get('symbol') || '';
  }

  let areAllVolumesZero = true;
  if (volumes && volumes.length > 0) {
    areAllVolumesZero = volumes.every(v => !v.volume || v.volume === 0);
  }

  const chartData = useMemo(() => {
    if (!data || data.length === 0) {
      return [];
    }

    return data.map((candle, index) => {
      const volumeData = volumes?.[index];
      const ma200Data = ma200?.find(m => new Date(m.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const bbData = bollingerBands?.find(b => new Date(b.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const sarData = sar?.find(s => new Date(s.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const volMAData = volumeMA?.find(v => new Date(v.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const rsiData = rsi?.find(r => new Date(r.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const macdData = macd?.find(m => new Date(m.timestamp).getTime() === new Date(candle.timestamp).getTime());

      const open = Number(candle.open);
      const high = Number(candle.high);
      const low = Number(candle.low);
      const close = Number(candle.close);
      const volume = Number(volumeData?.volume || 0);

      const isBullish = close >= open;

      return {
        index, // Store original index for XAxis domain mapping
        timestamp: candle.timestamp,
        open,
        high,
        low,
        close,
        priceRange: [low, high],
        volume,
        volumeMA: volMAData ? Number(volMAData.value) : null,
        ma200: ma200Data?.value ? Number(ma200Data.value) : null,
        bbUpper: bbData?.upper ? Number(bbData.upper) : null,
        bbMiddle: bbData?.middle ? Number(bbData.middle) : null,
        bbLower: bbData?.lower ? Number(bbData.lower) : null,
        sar: sarData?.value ? Number(sarData.value) : null,
        rsi: rsiData?.value ? Number(rsiData.value) : null,
        macd: macdData?.macd ? Number(macdData.macd) : null,
        isBullish
      };
    });
  }, [data, volumes, ma200, bollingerBands, sar, volumeMA, rsi, macd]);

  const globalBounds = useMemo(() => {
    if (!chartData || chartData.length === 0) return { min: 0, max: 100 };
    let minP = Infinity;
    let maxP = -Infinity;
    for (let i = 0; i < chartData.length; i++) {
      const d = chartData[i];
      if (d.low < minP) minP = d.low;
      if (d.high > maxP) maxP = d.high;
      if (showMA200 && d.ma200 && d.ma200 < minP) minP = d.ma200;
      if (showMA200 && d.ma200 && d.ma200 > maxP) maxP = d.ma200;
      if (showBollinger && d.bbLower && d.bbLower < minP) minP = d.bbLower;
      if (showBollinger && d.bbUpper && d.bbUpper > maxP) maxP = d.bbUpper;
      if (showSAR && d.sar && d.sar < minP) minP = d.sar;
      if (showSAR && d.sar && d.sar > maxP) maxP = d.sar;
    }
    if (minP === Infinity) {
      minP = 0;
      maxP = 100;
    } else {
      const padding = (maxP - minP) * 0.05;
      minP -= padding;
      maxP += padding;
    }
    return { min: minP, max: maxP };
  }, [chartData, showMA200, showBollinger, showSAR]);

  const calculateInitialState = (chartDataArray) => {
    if (!chartDataArray || chartDataArray.length === 0) return null;
    
    const lastCandle = chartDataArray[chartDataArray.length - 1];
    const maxTimestamp = new Date(lastCandle.timestamp).getTime();
    
    const cutoffDate = new Date(maxTimestamp);
    switch (selectedPeriod) {
      case '1m': cutoffDate.setMonth(cutoffDate.getMonth() - 1); break;
      case '2m': cutoffDate.setMonth(cutoffDate.getMonth() - 2); break;
      case '3m': cutoffDate.setMonth(cutoffDate.getMonth() - 3); break;
      case '6m': cutoffDate.setMonth(cutoffDate.getMonth() - 6); break;
      case '1y': cutoffDate.setFullYear(cutoffDate.getFullYear() - 1); break;
      case '2y': cutoffDate.setFullYear(cutoffDate.getFullYear() - 2); break;
      case '5y': cutoffDate.setFullYear(cutoffDate.getFullYear() - 5); break;
      default: cutoffDate.setFullYear(cutoffDate.getFullYear() - 1); break;
    }
    const cutoffTime = cutoffDate.getTime();
    
    let startIdx = 0;
    for (let i = 0; i < chartDataArray.length; i++) {
      if (new Date(chartDataArray[i].timestamp).getTime() >= cutoffTime) {
        startIdx = i;
        break;
      }
    }
    
    const endIdx = chartDataArray.length - 1;
    
    let minP = Infinity;
    let maxP = -Infinity;
    
    // Calculate initial Y axis scale based on the VISIBLE dataset
    for (let i = startIdx; i <= endIdx; i++) {
      const d = chartDataArray[i];
      if (d.low < minP) minP = d.low;
      if (d.high > maxP) maxP = d.high;
      if (showMA200 && d.ma200 && d.ma200 < minP) minP = d.ma200;
      if (showMA200 && d.ma200 && d.ma200 > maxP) maxP = d.ma200;
      if (showBollinger && d.bbLower && d.bbLower < minP) minP = d.bbLower;
      if (showBollinger && d.bbUpper && d.bbUpper > maxP) maxP = d.bbUpper;
      if (showSAR && d.sar && d.sar < minP) minP = d.sar;
      if (showSAR && d.sar && d.sar > maxP) maxP = d.sar;
    }

    if (minP === Infinity) {
      minP = 0;
      maxP = 100;
    } else {
      const padding = (maxP - minP) * 0.05;
      minP -= padding;
      maxP += padding;
    }

    return {
      startIndex: startIdx,
      endIndex: endIdx,
      minPrice: minP,
      maxPrice: maxP,
      isInitialized: true
    };
  };

  useEffect(() => {
    if (chartData && chartData.length > 0) {
      const initialState = calculateInitialState(chartData);
      if (initialState) {
        setViewState(initialState);
      }
    }
  }, [chartData, showMA200, showBollinger, showSAR, selectedPeriod]);

  // Data slicing logic
  const startIdx = Math.max(0, Math.floor(viewState.startIndex));
  const endIdx = Math.min((chartData?.length || 1) - 1, Math.ceil(viewState.endIndex));

  const visibleData = useMemo(() => {
    if (!chartData || !viewState.isInitialized) return [];
    const sliced = chartData.slice(startIdx, endIdx + 1);
    return sliced;
  }, [chartData, startIdx, endIdx, viewState.isInitialized]);

  const lastVisibleCandle = visibleData.length > 0 ? visibleData[visibleData.length - 1] : null;
  const activeCandle = (hoveredCandleIndex !== null && visibleData[hoveredCandleIndex]) 
    ? visibleData[hoveredCandleIndex] 
    : lastVisibleCandle;

  const handleMouseDown = (e) => {
    if (!viewState.isInitialized) return;
    setDragState({
      isDragging: true,
      startX: e.clientX,
      startY: e.clientY,
      initialStartIndex: viewState.startIndex,
      initialEndIndex: viewState.endIndex,
      initialMinPrice: viewState.minPrice,
      initialMaxPrice: viewState.maxPrice
    });
  };

  const handleMouseMove = (e) => {
    if (!containerRef.current || !chartData.length) return;

    if (dragState.isDragging) {
      const deltaX = e.clientX - dragState.startX;
      const deltaY = e.clientY - dragState.startY;

      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      if (width === 0 || height === 0) return;

      const candlesVisible = dragState.initialEndIndex - dragState.initialStartIndex;
      
      // Horizontal drag = Pan time window
      const candleWidth = width / Math.max(1, candlesVisible);
      const indexDelta = -Math.round(deltaX / candleWidth);
      
      let newStart = dragState.initialStartIndex + indexDelta;
      let newEnd = dragState.initialEndIndex + indexDelta;

      // Prevent scrolling beyond available data while maintaining fixed window width
      if (candlesVisible >= chartData.length - 1) {
        newStart = 0;
        newEnd = chartData.length - 1;
      } else {
        if (newStart < 0) {
          newStart = 0;
          newEnd = candlesVisible;
        }
        if (newEnd > chartData.length - 1) {
          newEnd = chartData.length - 1;
          newStart = chartData.length - 1 - candlesVisible;
        }
      }

      // Vertical drag = Pan price axis
      const priceRange = dragState.initialMaxPrice - dragState.initialMinPrice;
      const priceUnits = (deltaY * priceRange) / height;
      
      let newMinPrice = dragState.initialMinPrice + priceUnits;
      let newMaxPrice = dragState.initialMaxPrice + priceUnits;

      // Bounds checking for vertical pan
      if (newMinPrice < globalBounds.min) {
        newMinPrice = globalBounds.min;
        newMaxPrice = newMinPrice + priceRange;
      }
      if (newMaxPrice > globalBounds.max) {
        newMaxPrice = globalBounds.max;
        newMinPrice = newMaxPrice - priceRange;
      }

      setViewState(prev => ({
        ...prev,
        startIndex: newStart,
        endIndex: newEnd,
        minPrice: newMinPrice,
        maxPrice: newMaxPrice
      }));
      return;
    }

    // Hover logic
    if (chartAreaRef.current && visibleData.length > 0) {
      const rect = chartAreaRef.current.getBoundingClientRect();
      const mouseX = e.clientX;
      const mouseY = e.clientY;
      const chartLeftOffset = rect.left;
      const chartTopOffset = rect.top;
      const chartWidth = rect.width;
      const chartHeight = rect.height;

      if (mouseX >= chartLeftOffset && mouseX <= chartLeftOffset + chartWidth &&
          mouseY >= chartTopOffset && mouseY <= chartTopOffset + chartHeight) {
        
        const relativeX = mouseX - chartLeftOffset;
        const relativeY = mouseY - chartTopOffset;
        
        const candleWidth = chartWidth / visibleData.length;
        let candleIndex = Math.floor(relativeX / candleWidth);
        candleIndex = Math.max(0, Math.min(candleIndex, visibleData.length - 1));
        
        setHoveredCandleIndex(candleIndex);
        setMousePos({ x: relativeX, y: relativeY });

        const topMargin = 10;
        const effectiveHeight = chartHeight - topMargin;
        const yPos = relativeY - topMargin;
        const clampedY = Math.max(0, Math.min(yPos, effectiveHeight));
        const priceRange = viewState.maxPrice - viewState.minPrice;
        const calcPrice = viewState.maxPrice - (clampedY / effectiveHeight) * priceRange;
        
        setHoveredPrice(calcPrice);

      } else {
        setHoveredCandleIndex(null);
        setMousePos({ x: null, y: null });
        setHoveredPrice(null);
      }
    }
  };

  const handleMouseUp = () => {
    setDragState(prev => ({ ...prev, isDragging: false }));
  };

  const handleMouseLeave = () => {
    setDragState(prev => ({ ...prev, isDragging: false }));
    setHoveredCandleIndex(null);
    setMousePos({ x: null, y: null });
    setHoveredPrice(null);
  };

  const handleDoubleClick = () => {
    if (chartData && chartData.length > 0) {
      const initialState = calculateInitialState(chartData);
      if (initialState) {
        setViewState(initialState);
      }
    }
  };

  const handleYZoom = (direction) => {
    setViewState(prev => {
      if (!prev.isInitialized) return prev;
      
      const currentRange = prev.maxPrice - prev.minPrice;
      const center = prev.minPrice + currentRange / 2;
      const factor = direction === 'in' ? 0.833 : 1.2;
      let newRange = currentRange * factor;
      
      // Prevent zooming in too much
      if (newRange < 0.0001) newRange = 0.0001;
      
      let newMin = center - newRange / 2;
      let newMax = center + newRange / 2;
      
      // Bounds checking
      if (newMin < globalBounds.min) {
        newMin = globalBounds.min;
      }
      if (newMax > globalBounds.max) {
        newMax = globalBounds.max;
      }
      
      // If after clamping the range is invalid, just return prev
      if (newMin >= newMax) return prev;
      
      return {
        ...prev,
        minPrice: newMin,
        maxPrice: newMax
      };
    });
  };

  const handleXZoom = (direction) => {
    setViewState(prev => {
      if (!prev.isInitialized || !chartData.length) return prev;

      const currentStart = prev.startIndex;
      const currentEnd = prev.endIndex;
      let currentWidth = currentEnd - currentStart;

      // Prevent zero width
      if (currentWidth < 1) currentWidth = 1;

      const center = currentStart + currentWidth / 2;
      const factor = 1.2;

      let newWidth = direction === 'in' ? currentWidth / factor : currentWidth * factor;

      // Constraints
      const minWidth = 5; // minimum 5 candles visible
      const maxWidth = chartData.length - 1; // max all candles

      if (newWidth < minWidth) newWidth = minWidth;
      if (newWidth > maxWidth) newWidth = maxWidth;

      let newStart = center - newWidth / 2;
      let newEnd = center + newWidth / 2;

      // Bounds checking, shift if necessary to maintain requested width
      if (newStart < 0) {
        newStart = 0;
        newEnd = Math.min(newWidth, maxWidth);
      }
      if (newEnd > maxWidth) {
        newEnd = maxWidth;
        newStart = Math.max(0, maxWidth - newWidth);
      }

      return {
        ...prev,
        startIndex: newStart,
        endIndex: newEnd
      };
    });
  };

  const xTicks = useMemo(() => {
    if (!viewState.isInitialized || !chartData.length) return [];
    const numTicks = 6;
    const step = Math.max(1, Math.floor((endIdx - startIdx) / (numTicks - 1)));
    const ticks = [];
    
    for (let i = startIdx; i <= endIdx; i += step) {
      ticks.push(i);
    }
    
    if (ticks[ticks.length - 1] !== endIdx) {
      ticks[ticks.length - 1] = endIdx;
    }
    
    return ticks;
  }, [startIdx, endIdx, viewState.isInitialized, chartData.length]);

  const formatPrice = (value) => {
    if (value === null || value === undefined || isNaN(value)) return '';
    const currencySymbol = getCurrencySymbol(activeSymbol);
    const isEuroFormat = currencySymbol === '€';
    const numStr = Number(value).toFixed(2);
    return isEuroFormat ? `${currencySymbol}${numStr.replace('.', ',')}` : `${currencySymbol}${numStr}`;
  };

  const formatXAxis = (index) => {
    const candle = chartData[index];
    if (!candle) return '';
    const date = new Date(candle.timestamp);
    const hasTime = date.getHours() !== 0 || date.getMinutes() !== 0;
    return hasTime ? format(date, 'MMM dd HH:mm') : format(date, 'MMM dd');
  };

  const getHoveredDateStr = (candle) => {
    if (!candle) return '';
    const date = new Date(candle.timestamp);
    const hasTime = date.getHours() !== 0 || date.getMinutes() !== 0;
    return hasTime ? format(date, 'dd MMM yyyy HH:mm') : format(date, 'dd MMM yyyy');
  };

  const CustomCandlestick = (props) => {
    const { x, y, width, height, payload } = props;
    if (!payload) return null;

    const { open, close, high, low, isBullish } = payload;
    const color = isBullish ? 'hsl(var(--bullish, 142.1 76.2% 36.3%))' : 'hsl(var(--bearish, 346.8 77.2% 49.8%))';
    
    const wickX = x + width / 2;
    const range = high - low;

    if (range === 0) {
      return <line x1={x} y1={y} x2={x + width} y2={y} stroke={color} strokeWidth={1} />;
    }

    const openY = y + height * ((high - open) / range);
    const closeY = y + height * ((high - close) / range);

    const bodyTop = Math.min(openY, closeY);
    const bodyBottom = Math.max(openY, closeY);
    const bodyHeight = Math.max(1, bodyBottom - bodyTop);

    return (
      <g>
        <line x1={wickX} y1={y} x2={wickX} y2={bodyTop} stroke={color} strokeWidth={1} />
        <line x1={wickX} y1={bodyBottom} x2={wickX} y2={y + height} stroke={color} strokeWidth={1} />
        <rect
          x={x}
          y={bodyTop}
          width={width}
          height={bodyHeight}
          fill={color}
          stroke={color}
          strokeWidth={1}
        />
      </g>
    );
  };

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || payload.length === 0 || dragState.isDragging) return null;

    const data = payload[0].payload;
    const date = new Date(data.timestamp);

    return (
      <div 
        className="absolute bg-slate-950 border border-slate-800 p-2 rounded-lg shadow-2xl text-xs text-slate-200 min-w-[180px] z-[100] pointer-events-none"
        style={{ top: '0', left: '0' }}
      >
        <div className="font-semibold mb-2 border-b border-slate-800 pb-1 text-slate-50">
          {format(date, 'MMM dd, yyyy HH:mm')}
        </div>
        <div className="grid grid-cols-2 gap-x-3 gap-y-1">
          <span className="text-slate-400">Open:</span>
          <span className="font-medium text-right">{formatPrice(data.open)}</span>
          
          <span className="text-slate-400">High:</span>
          <span className="font-medium text-right">{formatPrice(data.high)}</span>
          
          <span className="text-slate-400">Low:</span>
          <span className="font-medium text-right">{formatPrice(data.low)}</span>
          
          <span className="text-slate-400">Close:</span>
          <span className="font-medium text-right">{formatPrice(data.close)}</span>
          
          <span className="text-slate-400">Volume:</span>
          <span className="font-medium text-right">{data.volume?.toLocaleString()}</span>
          
          {showMA200 && data.ma200 !== null && data.ma200 !== undefined && (
            <>
              <span className="text-blue-400">MA ({ma200Period} {ma200Type}):</span>
              <span className="font-medium text-right text-blue-400">{formatPrice(data.ma200)}</span>
            </>
          )}
          
          {showBollinger && data.bbUpper !== null && data.bbUpper !== undefined && (
            <>
              <span className="text-purple-400">BB Upper:</span>
              <span className="font-medium text-right text-purple-400">{formatPrice(data.bbUpper)}</span>
              <span className="text-purple-400">BB Lower:</span>
              <span className="font-medium text-right text-purple-400">{formatPrice(data.bbLower)}</span>
            </>
          )}
          
          {showSAR && data.sar !== null && data.sar !== undefined && (
            <>
              <span className="text-orange-400">SAR:</span>
              <span className="font-medium text-right text-orange-400">{formatPrice(data.sar)}</span>
            </>
          )}

          {showVolumeMA && data.volumeMA !== null && data.volumeMA !== undefined && (
            <>
              <span className="text-amber-400">Vol MA ({volumeMAPeriod}):</span>
              <span className="font-medium text-right text-amber-400">{data.volumeMA?.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </>
          )}
        </div>
      </div>
    );
  };

  if (!chartData || chartData.length === 0 || !viewState.isInitialized) {
    return (
      <div className="flex items-center justify-center h-96 bg-card rounded-xl border border-border">
        <p className="text-muted-foreground">No chart data available</p>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className={`transition-all duration-300 ${isFullscreen ? 'fixed inset-0 z-50 w-screen h-screen bg-background p-2 sm:p-4 flex flex-col overflow-hidden gap-2 sm:gap-4' : 'space-y-6 relative'} ${dragState.isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
      style={{ userSelect: 'none' }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
      onDoubleClick={handleDoubleClick}
    >
      <div 
        className={`bg-card rounded-xl border border-border relative shadow-sm w-full flex flex-col ${isFullscreen ? 'p-2 sm:p-4 flex-none' : 'p-6'}`}
        style={isFullscreen ? { height: 'auto', minHeight: '80vh' } : {}}
      >
        {!isFullscreen && (
          <div className="flex items-center justify-between mb-4 shrink-0">
            <div className="flex items-center gap-4">
              <h3 className="text-lg font-semibold" style={{ letterSpacing: '-0.01em' }}>
                Price Chart
              </h3>
              <div className="flex items-center gap-2">
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="h-8 w-8 transition-all duration-200 active:scale-95" aria-label="Y-Axis Zoom">
                      <ArrowUpDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start">
                    <DropdownMenuItem onClick={() => handleYZoom('in')} className="cursor-pointer">
                      <ArrowUp className="h-4 w-4 mr-2" />
                      Zoom In (Y-Axis)
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleYZoom('out')} className="cursor-pointer">
                      <ArrowDown className="h-4 w-4 mr-2" />
                      Zoom Out (Y-Axis)
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="icon" className="h-8 w-8 transition-all duration-200 active:scale-95" aria-label="X-Axis Zoom">
                      <ArrowLeftRight className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="start">
                    <DropdownMenuItem onClick={() => handleXZoom('in')} className="cursor-pointer">
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Zoom In (X-Axis)
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => handleXZoom('out')} className="cursor-pointer">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      Zoom Out (X-Axis)
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
            <div className="text-xs text-muted-foreground hidden sm:block">
              Drag horizontally to pan time • Drag vertically to pan price • Double-click to reset
            </div>
          </div>
        )}
        <div className="flex-1 min-h-0 w-full overflow-hidden pointer-events-none relative" ref={chartAreaRef}>
          
          {/* Crosshair Lines and Labels */}
          {mousePos.x !== null && mousePos.y !== null && !dragState.isDragging && (
            <>
              <div 
                className="absolute top-0 bottom-0 pointer-events-none z-10"
                style={{
                  left: mousePos.x,
                  width: '1px',
                  borderLeft: '1px dashed #888',
                  opacity: 0.7
                }}
              />
              <div 
                className="absolute left-0 right-0 pointer-events-none z-10"
                style={{
                  top: mousePos.y,
                  height: '1px',
                  borderTop: '1px dashed #888',
                  opacity: 0.7
                }}
              />
              
              {/* Price Label (Right) */}
              {hoveredPrice !== null && (
                <div 
                  className="absolute right-0 z-30 bg-[#222] text-white border border-[#444] text-xs px-2 py-1 rounded-sm pointer-events-none shadow-sm"
                  style={{ top: mousePos.y, transform: 'translateY(-50%)' }}
                >
                  {formatPrice(hoveredPrice)}
                </div>
              )}
              
              {/* DateTime Label (Bottom) */}
              {activeCandle && (
                <div 
                  className="absolute bottom-0 z-30 bg-[#222] text-white border border-[#444] text-xs px-2 py-1 rounded-sm pointer-events-none shadow-sm whitespace-nowrap"
                  style={{ left: mousePos.x, transform: 'translateX(-50%)' }}
                >
                  {getHoveredDateStr(activeCandle)}
                </div>
              )}
            </>
          )}

          {/* Price and Indicators Overlay */}
          {activeCandle && (
            <div className="price-indicators-table">
              <table>
                <thead>
                  <tr>
                    <th colSpan="2">Price Data</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Open</td>
                    <td>{formatPrice(activeCandle.open)}</td>
                  </tr>
                  <tr>
                    <td>High</td>
                    <td>{formatPrice(activeCandle.high)}</td>
                  </tr>
                  <tr>
                    <td>Low</td>
                    <td>{formatPrice(activeCandle.low)}</td>
                  </tr>
                  <tr>
                    <td>Close</td>
                    <td>{formatPrice(activeCandle.close)}</td>
                  </tr>
                  <tr>
                    <td>Volume</td>
                    <td>{activeCandle.volume?.toLocaleString()}</td>
                  </tr>
                  <tr>
                    <td>Change</td>
                    <td className={activeCandle.close >= activeCandle.open ? 'text-positive' : 'text-negative'}>
                      {formatPrice(activeCandle.close - activeCandle.open)} 
                      <span className="ml-1 text-[0.65rem]">
                        ({(((activeCandle.close - activeCandle.open) / activeCandle.open) * 100).toFixed(2)}%)
                      </span>
                    </td>
                  </tr>
                </tbody>
                
                <thead className="divider">
                  <tr>
                    <th colSpan="2">Indicators</th>
                  </tr>
                </thead>
                <tbody>
                  {activeCandle.rsi !== null && activeCandle.rsi !== undefined && (
                    <tr>
                      <td>RSI</td>
                      <td>{activeCandle.rsi.toFixed(2)}</td>
                    </tr>
                  )}
                  {activeCandle.macd !== null && activeCandle.macd !== undefined && (
                    <tr>
                      <td>MACD</td>
                      <td>{activeCandle.macd.toFixed(2)}</td>
                    </tr>
                  )}
                  {showBollinger && activeCandle.bbUpper !== null && activeCandle.bbUpper !== undefined && (
                    <>
                      <tr>
                        <td>BB Upper</td>
                        <td>{formatPrice(activeCandle.bbUpper)}</td>
                      </tr>
                      <tr>
                        <td>BB Middle</td>
                        <td>{formatPrice(activeCandle.bbMiddle)}</td>
                      </tr>
                      <tr>
                        <td>BB Lower</td>
                        <td>{formatPrice(activeCandle.bbLower)}</td>
                      </tr>
                    </>
                  )}
                  {activeCandle.volumeMA !== null && activeCandle.volumeMA !== undefined && (
                    <tr>
                      <td>Avg Vol</td>
                      <td>{activeCandle.volumeMA.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          )}

          <ResponsiveContainer 
            width="100%" 
            height={isFullscreen ? "100%" : 400}
            style={isFullscreen ? { height: 'auto', minHeight: '80vh' } : {}}
          >
            {/* Pass the explicitly sliced visibleData */}
            <ComposedChart data={visibleData} margin={{ top: 10, right: 40, left: 0, bottom: 0 }}>
              <CartesianGrid 
                vertical={false}
                strokeDasharray="5 5" 
                stroke="hsl(var(--chart-grid))" 
                strokeOpacity={0.25} 
                strokeWidth={1}
              />
              
              {xTicks.map(tick => (
                <ReferenceLine 
                  key={`ref-${tick}`} 
                  x={tick} 
                  stroke="hsl(var(--chart-grid))" 
                  strokeOpacity={0.25} 
                  strokeDasharray="5 5" 
                  strokeWidth={1} 
                />
              ))}
              
              <XAxis
                type="number"
                dataKey="index"
                domain={['dataMin', 'dataMax']}
                allowDecimals={false}
                tickFormatter={formatXAxis}
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '0.75rem' }}
                tickMargin={10}
                ticks={xTicks}
                allowDataOverflow
              />
              <YAxis
                domain={[viewState.minPrice, viewState.maxPrice]}
                stroke="hsl(var(--muted-foreground))"
                style={{ fontSize: '0.75rem' }}
                tickFormatter={formatPrice}
                tickMargin={10}
                tickCount={7}
                allowDataOverflow
              />
              <Tooltip 
                content={<CustomTooltip />} 
                position={{ x: 10, y: 10 }}
                cursor={false}
                isAnimationActive={false}
              />
              <Legend
                wrapperStyle={{ fontSize: '0.875rem', paddingTop: '10px' }}
                iconType="line"
              />
              
              {showBollinger && (
                <Line
                  type="monotone"
                  dataKey="bbUpper"
                  stroke="#a855f7"
                  strokeWidth={1.5}
                  strokeDasharray="5 5"
                  dot={false}
                  name="BB Upper"
                  connectNulls
                  isAnimationActive={false}
                />
              )}
              {showBollinger && (
                <Line
                  type="monotone"
                  dataKey="bbLower"
                  stroke="#a855f7"
                  strokeWidth={1.5}
                  strokeDasharray="5 5"
                  dot={false}
                  name="BB Lower"
                  connectNulls
                  isAnimationActive={false}
                />
              )}
              
              {showMA200 && (
                <Line
                  type="monotone"
                  dataKey="ma200"
                  stroke="#3b82f6"
                  strokeWidth={2}
                  dot={false}
                  name={`MA (${ma200Period} ${ma200Type})`}
                  connectNulls
                  isAnimationActive={false}
                />
              )}
              
              {showSAR && (
                <Line
                  type="monotone"
                  dataKey="sar"
                  stroke="#f97316"
                  strokeWidth={1}
                  strokeDasharray="4 2"
                  strokeOpacity={0.85}
                  dot={false}
                  name="SAR"
                  connectNulls
                  isAnimationActive={false}
                />
              )}
              
              <Bar
                dataKey="priceRange"
                shape={<CustomCandlestick />}
                name="Price"
                isAnimationActive={false}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className={`bg-card rounded-xl border border-border relative shadow-sm w-full flex flex-col ${isFullscreen ? 'p-2 sm:p-4 flex-1 min-h-0' : 'p-6'}`}>
        {!isFullscreen && (
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 shrink-0">
            <h3 className="text-lg font-semibold" style={{ letterSpacing: '-0.01em' }}>
              Volume
            </h3>
            <div className="flex flex-wrap items-center gap-4 bg-muted/50 p-2 rounded-lg border border-border/50">
              <div className="flex items-center gap-2">
                <Checkbox 
                  id="volume-ma-toggle" 
                  checked={showVolumeMA} 
                  onCheckedChange={setShowVolumeMA} 
                />
                <Label htmlFor="volume-ma-toggle" className="text-sm font-medium cursor-pointer">
                  Mostra Media Mobile Volumi
                </Label>
              </div>
              {showVolumeMA && (
                <div className="flex items-center gap-2 border-l border-border/50 pl-4">
                  <Label htmlFor="volume-ma-period" className="text-sm text-muted-foreground whitespace-nowrap">
                    Periodo MA:
                  </Label>
                  <Input 
                    id="volume-ma-period"
                    type="number"
                    min={1}
                    max={200}
                    step={1}
                    value={volumeMAPeriod}
                    onChange={(e) => setVolumeMAPeriod(Number(e.target.value))}
                    className="w-20 h-8 text-sm px-2 py-1"
                  />
                </div>
              )}
            </div>
          </div>
        )}
        {areAllVolumesZero ? (
          <div className={`flex items-center justify-center p-[20px] bg-muted/30 rounded-lg ${isFullscreen ? 'flex-1 h-full' : 'min-h-[150px]'}`}>
            <p className="text-muted-foreground text-sm italic text-center">
              Volume data not available for intraday timeframes on indices
            </p>
          </div>
        ) : (
          <div className="flex-1 min-h-0 w-full overflow-hidden pointer-events-none">
            <ResponsiveContainer width="100%" height={isFullscreen ? "100%" : 150}>
              <ComposedChart data={visibleData} margin={{ top: 10, right: 40, left: 0, bottom: 0 }}>
                <CartesianGrid 
                  vertical={false}
                  strokeDasharray="5 5" 
                  stroke="hsl(var(--chart-grid))" 
                  strokeOpacity={0.25} 
                  strokeWidth={1}
                />
                
                {xTicks.map(tick => (
                  <ReferenceLine 
                    key={`ref-vol-${tick}`} 
                    x={tick} 
                    stroke="hsl(var(--chart-grid))" 
                    strokeOpacity={0.25} 
                    strokeDasharray="5 5" 
                    strokeWidth={1} 
                  />
                ))}
                
                <XAxis
                  type="number"
                  dataKey="index"
                  domain={['dataMin', 'dataMax']}
                  allowDecimals={false}
                  tickFormatter={formatXAxis}
                  stroke="hsl(var(--muted-foreground))"
                  style={{ fontSize: '0.75rem' }}
                  tickMargin={10}
                  ticks={xTicks}
                  allowDataOverflow
                />
                <YAxis
                  stroke="hsl(var(--muted-foreground))"
                  style={{ fontSize: '0.75rem' }}
                  tickFormatter={(value) => {
                    if (value >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
                    if (value >= 1000) return `${(value / 1000).toFixed(1)}K`;
                    return value;
                  }}
                  tickMargin={10}
                  tickCount={5}
                />
                <Tooltip 
                  content={<CustomTooltip />} 
                  position={{ x: 10, y: 10 }}
                  cursor={{ fill: 'hsl(var(--muted))', opacity: 0.2 }}
                  isAnimationActive={false}
                />
                <Bar
                  dataKey="volume"
                  fill="hsl(var(--primary) / 0.5)"
                  name="Volume"
                  isAnimationActive={false}
                />
                {showVolumeMA && (
                  <Line
                    type="monotone"
                    dataKey="volumeMA"
                    stroke="#f59e0b"
                    strokeWidth={1.5}
                    dot={false}
                    name={`Volume MA (${volumeMAPeriod})`}
                    connectNulls
                    isAnimationActive={false}
                  />
                )}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        )}
      </div>
    </div>
  );
};

export default CandlestickChart;
