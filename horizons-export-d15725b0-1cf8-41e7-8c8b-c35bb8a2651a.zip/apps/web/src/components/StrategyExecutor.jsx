
import React, { useState } from 'react';
import { format } from 'date-fns';
import { Calendar as CalendarIcon, Play, AlertCircle, Info, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { validateLiquidity } from '@/lib/StrategyCalculator';

const StrategyExecutor = ({ onExecute, loading, initialPrice, candlesticks, symbol }) => {
  const endDate = new Date();
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setFullYear(date.getFullYear() - 1);
    return date;
  });
  
  const [initialCapital, setInitialCapital] = useState(10000);
  const [sharesPerTrade, setSharesPerTrade] = useState(100);
  const [errorMsg, setErrorMsg] = useState('');

  // Data Validation
  const candleCount = candlesticks?.length || 0;
  const isEnoughData = candleCount >= 250;
  const firstDate = candlesticks?.[0]?.timestamp ? new Date(candlesticks[0].timestamp) : null;
  const lastDate = candlesticks?.[candleCount - 1]?.timestamp ? new Date(candlesticks[candleCount - 1].timestamp) : null;
  
  const minPrice = candlesticks && candleCount > 0 ? Math.min(...candlesticks.map(c => c.low)) : 0;
  const maxPrice = candlesticks && candleCount > 0 ? Math.max(...candlesticks.map(c => c.high)) : 0;
  
  // Suspicious data check (e.g., GOOGL should generally be between $50 and $400 in recent years)
  const isSuspicious = symbol?.toUpperCase() === 'GOOGL' && (minPrice < 50 || maxPrice > 400);

  const handleExecute = () => {
    setErrorMsg('');
    
    if (!isEnoughData) {
      setErrorMsg(`Dati insufficienti per il backtest. Trovate ${candleCount} candele, necessarie almeno 250 per MA200 e SAR.`);
      return;
    }

    if (startDate && initialCapital > 0 && sharesPerTrade > 0) {
      if (initialPrice) {
        const validation = validateLiquidity(initialCapital, initialPrice, sharesPerTrade);
        if (!validation.isValid) {
          setErrorMsg(validation.message);
          return;
        }
      }
      
      onExecute(startDate, endDate, initialCapital, sharesPerTrade);
    }
  };

  return (
    <Card className="mb-6 shadow-sm border-border">
      <CardHeader className="pb-3">
        <CardTitle className="text-xl">Configurazione Strategia</CardTitle>
        <CardDescription>
          Imposta i parametri di capitale e seleziona il periodo per il backtest.
        </CardDescription>
      </CardHeader>
      <CardContent>
        
        {/* Data Validation Info Panel */}
        <div className="mb-6 p-4 bg-muted/30 rounded-xl border border-border/50 space-y-3">
          <div className="flex items-center gap-2 text-sm font-medium text-foreground">
            <Info className="w-4 h-4 text-primary" />
            Sorgente Dati: Yahoo Finance
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
            <div>
              <span className="text-muted-foreground block text-xs uppercase tracking-wider">Candele Disponibili</span>
              <span className={cn("font-medium", !isEnoughData && "text-destructive")}>{candleCount}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs uppercase tracking-wider">Range Date</span>
              <span className="font-medium">
                {firstDate ? format(firstDate, 'dd/MM/yy') : '--'} - {lastDate ? format(lastDate, 'dd/MM/yy') : '--'}
              </span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs uppercase tracking-wider">Prezzo Min</span>
              <span className="font-medium">{minPrice > 0 ? minPrice.toFixed(2) : '--'}</span>
            </div>
            <div>
              <span className="text-muted-foreground block text-xs uppercase tracking-wider">Prezzo Max</span>
              <span className="font-medium">{maxPrice > 0 ? maxPrice.toFixed(2) : '--'}</span>
            </div>
          </div>
          
          {!isEnoughData && (
            <div className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 p-2 rounded-md mt-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <p>Attenzione: Non ci sono abbastanza dati storici (minimo 250 candele) per calcolare correttamente la MA200 e il SAR. Seleziona un periodo più lungo nell'Analisi Tecnica.</p>
            </div>
          )}
          
          {isSuspicious && (
            <div className="flex items-start gap-2 text-sm text-amber-600 bg-amber-50 p-2 rounded-md mt-2">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <p>Attenzione: I prezzi rilevati per {symbol} sembrano anomali rispetto al range atteso. Verifica la correttezza dei dati.</p>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
          <div className="flex flex-col gap-2">
            <Label htmlFor="initial-capital">Capitale Iniziale (€)</Label>
            <Input 
              id="initial-capital"
              type="number" 
              min="100" 
              step="100"
              value={initialCapital} 
              onChange={(e) => setInitialCapital(Number(e.target.value))}
              className="w-full"
            />
          </div>
          
          <div className="flex flex-col gap-2">
            <Label htmlFor="shares-per-trade">Azioni per Trade</Label>
            <Input 
              id="shares-per-trade"
              type="number" 
              min="1" 
              step="1"
              value={sharesPerTrade} 
              onChange={(e) => setSharesPerTrade(Number(e.target.value))}
              className="w-full"
            />
          </div>

          <div className="flex flex-col gap-2">
            <Label>Data di Inizio</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant={"outline"}
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !startDate && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {startDate ? format(startDate, "dd/MM/yyyy") : <span>Seleziona data</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  initialFocus
                  disabled={(date) => date > endDate}
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <div className="flex flex-col gap-2">
            <Label>Data di Fine</Label>
            <Button
              variant="outline"
              disabled
              className="w-full justify-start text-left font-normal bg-muted/50 opacity-100"
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {format(endDate, "dd/MM/yyyy")}
            </Button>
          </div>
        </div>

        {errorMsg && (
          <div className="mt-4 p-3 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3 text-destructive">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <p className="text-sm font-medium">{errorMsg}</p>
          </div>
        )}

        <div className="flex justify-end mt-6">
          <Button 
            className="w-full sm:w-auto transition-all duration-200 active:scale-95" 
            onClick={handleExecute}
            disabled={loading || !startDate || initialCapital <= 0 || sharesPerTrade <= 0 || !isEnoughData}
          >
            <Play className="w-4 h-4 mr-2" />
            {loading ? "Calcolo in corso..." : "Esegui Strategia"}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default StrategyExecutor;
