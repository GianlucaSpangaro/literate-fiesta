
import React, { useState, useEffect, useRef } from 'react';
import { ChevronUp, ChevronDown, Trash2 } from 'lucide-react';
import { initDebugLogger, subscribeToLogs, clearLogs } from '@/lib/debugLogger.js';

// Initialize the logger when this file is evaluated
initDebugLogger();

export const useDebugLog = () => {
  return {
    log: console.log,
    warn: console.warn,
    error: console.error
  };
};

const DebugPanel = () => {
  const [logs, setLogs] = useState([]);
  const [isMinimized, setIsMinimized] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    const unsubscribe = subscribeToLogs((newLogs) => {
      setLogs(newLogs);
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (scrollRef.current && !isMinimized) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs, isMinimized]);

  const formatTime = (date) => {
    const d = new Date(date);
    const pad = (n) => n.toString().padStart(2, '0');
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  };

  const getLogColor = (type) => {
    switch (type) {
      case 'warning': return 'text-yellow-400';
      case 'error': return 'text-red-400';
      default: return 'text-white';
    }
  };

  return (
    <div 
      className="fixed bottom-[20px] right-[20px] z-[9999] w-[400px] flex flex-col font-mono text-sm shadow-2xl transition-all duration-300 ease-in-out"
      style={{
        background: 'rgba(0, 0, 0, 0.8)',
        border: '1px solid #444',
        borderRadius: '8px',
        padding: '12px'
      }}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-[#444] pb-2 mb-2 select-none">
        <div className="flex items-center gap-2">
          <span className="font-bold text-white tracking-wide">Debug Console</span>
          <span className="text-gray-400 text-xs">({logs.length}/50)</span>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={clearLogs}
            className="p-1 hover:bg-white/10 rounded transition-colors text-gray-300 hover:text-white"
            title="Clear Logs"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button 
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-1 hover:bg-white/10 rounded transition-colors text-gray-300 hover:text-white"
            title={isMinimized ? "Maximize" : "Minimize"}
          >
            {isMinimized ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Content Area */}
      {!isMinimized && (
        <div 
          ref={scrollRef}
          className="overflow-y-auto pr-1"
          style={{ maxHeight: '300px', minHeight: '100px' }}
        >
          {logs.length === 0 ? (
            <div className="text-gray-500 italic py-2 text-center">No logs recorded yet.</div>
          ) : (
            <div className="flex flex-col gap-1.5">
              {logs.map((log) => (
                <div key={log.id} className="break-words leading-tight">
                  <span className="text-gray-400 shrink-0 select-none">[{formatTime(log.timestamp)}]</span>{' '}
                  <span className={`uppercase font-bold text-xs shrink-0 select-none ${getLogColor(log.type)}`}>[{log.type}]</span>{' '}
                  <span className={`${getLogColor(log.type)} opacity-90 whitespace-pre-wrap`}>
                    {log.message}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default DebugPanel;
