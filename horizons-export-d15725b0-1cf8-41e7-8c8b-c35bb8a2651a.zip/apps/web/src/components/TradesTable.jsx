
import React from 'react';
import { format } from 'date-fns';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const TradesTable = ({ trades }) => {
  if (!trades || trades.length === 0) {
    return (
      <Card className="shadow-sm border-border">
        <CardContent className="p-12 text-center text-muted-foreground">
          Nessun trade effettuato nel periodo selezionato.
        </CardContent>
      </Card>
    );
  }

  const formatCurrency = (val) => new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(val);

  return (
    <Card className="shadow-sm border-border overflow-hidden">
      <CardHeader className="bg-muted/20 pb-4 border-b border-border">
        <CardTitle className="text-lg">Dettaglio Trade</CardTitle>
      </CardHeader>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/30 hover:bg-muted/30">
              <TableHead className="w-[80px]"># Trade</TableHead>
              <TableHead>Stato</TableHead>
              <TableHead>Data Entry</TableHead>
              <TableHead className="text-right">Prezzo Entry</TableHead>
              <TableHead>Data Exit</TableHead>
              <TableHead className="text-right">Prezzo Exit</TableHead>
              <TableHead className="text-right">Durata (gg)</TableHead>
              <TableHead className="text-right">Profitto (€)</TableHead>
              <TableHead className="text-right">Profitto (%)</TableHead>
              <TableHead className="text-right">Capitale Dopo Trade</TableHead>
              <TableHead className="text-right">Equity %</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {trades.map((trade, index) => {
              const tradeNum = trades.length - index;
              const isSkipped = trade.status === 'skipped';
              const isProfitable = !isSkipped && trade.profit > 0;
              const isLoss = !isSkipped && trade.profit < 0;
              
              return (
                <TableRow key={index} className={isSkipped ? "bg-destructive/5 hover:bg-destructive/10 transition-colors" : "hover:bg-muted/20 transition-colors"}>
                  <TableCell className="font-medium">{tradeNum}</TableCell>
                  <TableCell>
                    {isSkipped ? (
                      <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/20">Saltato - Capitale Insufficiente</Badge>
                    ) : trade.forcedClose ? (
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/20">Forzato</Badge>
                    ) : (
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-600 border-blue-500/20">Eseguito</Badge>
                    )}
                  </TableCell>
                  <TableCell>{format(new Date(trade.entryDate), 'dd/MM/yyyy')}</TableCell>
                  <TableCell className="text-right">{formatCurrency(trade.entryPrice)}</TableCell>
                  <TableCell>{format(new Date(trade.exitDate), 'dd/MM/yyyy')}</TableCell>
                  <TableCell className="text-right">{formatCurrency(trade.exitPrice)}</TableCell>
                  <TableCell className="text-right">{isSkipped ? '-' : Math.round(trade.duration)}</TableCell>
                  <TableCell className={`text-right font-medium ${isProfitable ? 'text-green-500' : isLoss ? 'text-red-500' : ''}`}>
                    {isSkipped ? '-' : `${trade.profit > 0 ? '+' : ''}${formatCurrency(trade.profit)}`}
                  </TableCell>
                  <TableCell className={`text-right font-medium ${isProfitable ? 'text-green-500' : isLoss ? 'text-red-500' : ''}`}>
                    {isSkipped ? '-' : `${trade.profitPercent > 0 ? '+' : ''}${trade.profitPercent.toFixed(2)}%`}
                  </TableCell>
                  <TableCell className="text-right font-medium">
                    {formatCurrency(trade.capitalAfterTrade)}
                  </TableCell>
                  <TableCell className="text-right">
                    {trade.equityPercent.toFixed(1)}%
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default TradesTable;
