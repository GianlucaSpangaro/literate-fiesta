
import React from 'react';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { format } from 'date-fns';

const MACDChart = ({ data }) => {
  const chartData = data?.map(item => ({
    timestamp: item.timestamp,
    macd: item.macd,
    signal: item.signal,
    histogram: item.histogram
  })) || [];

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload || payload.length === 0) return null;

    const data = payload[0].payload;
    const date = new Date(data.timestamp);

    return (
      <div className="chart-tooltip">
        <div className="chart-tooltip-label">
          {format(date, 'MMM dd, yyyy HH:mm')}
        </div>
        <div className="chart-tooltip-item">
          <span>MACD:</span>
          <span className="chart-tooltip-value">{data.macd?.toFixed(4)}</span>
        </div>
        <div className="chart-tooltip-item">
          <span>Signal:</span>
          <span className="chart-tooltip-value">{data.signal?.toFixed(4)}</span>
        </div>
        <div className="chart-tooltip-item">
          <span>Histogram:</span>
          <span className="chart-tooltip-value">{data.histogram?.toFixed(4)}</span>
        </div>
      </div>
    );
  };

  const formatXAxis = (timestamp) => {
    const date = new Date(timestamp);
    return format(date, 'MMM dd');
  };

  if (!chartData || chartData.length === 0) {
    return (
      <div className="flex items-center justify-center h-64 bg-card rounded-xl border border-border">
        <p className="text-muted-foreground">No MACD data available</p>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-xl border border-border p-6">
      <h3 className="text-lg font-semibold mb-4" style={{ letterSpacing: '-0.01em' }}>
        MACD (Moving Average Convergence Divergence)
      </h3>
      <ResponsiveContainer width="100%" height={250}>
        <ComposedChart data={chartData} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis
            dataKey="timestamp"
            tickFormatter={formatXAxis}
            stroke="hsl(var(--muted-foreground))"
            style={{ fontSize: '0.75rem' }}
          />
          <YAxis
            stroke="hsl(var(--muted-foreground))"
            style={{ fontSize: '0.75rem' }}
            tickFormatter={(value) => value.toFixed(3)}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend
            wrapperStyle={{ fontSize: '0.875rem' }}
            iconType="line"
          />
          <ReferenceLine y={0} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" />
          <Bar
            dataKey="histogram"
            fill="hsl(var(--volume))"
            name="Histogram"
          />
          <Line
            type="monotone"
            dataKey="macd"
            stroke="hsl(var(--macd))"
            strokeWidth={2}
            dot={false}
            name="MACD"
            connectNulls
          />
          <Line
            type="monotone"
            dataKey="signal"
            stroke="hsl(var(--sar))"
            strokeWidth={2}
            dot={false}
            name="Signal"
            connectNulls
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MACDChart;
