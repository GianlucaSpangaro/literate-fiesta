
import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const formatCurrency = (val) => new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR' }).format(val);
const formatPercent = (val) => `${val > 0 ? '+' : ''}${val.toFixed(2)}%`;
const formatNumber = (val) => val.toFixed(2);

const StatItem = ({ label, value, isPositive = null, suffix = '', subValue = null, highlight = false }) => (
  <div className={`flex flex-col gap-1 p-4 rounded-xl border ${highlight ? 'bg-destructive/5 border-destructive/20' : 'bg-muted/30 border-border/50'}`}>
    <span className={`text-xs font-medium uppercase tracking-wider ${highlight ? 'text-destructive' : 'text-muted-foreground'}`}>{label}</span>
    <div className="flex items-baseline gap-2">
      <span className={`text-xl font-bold ${isPositive === true ? 'text-green-500' : isPositive === false ? 'text-red-500' : highlight ? 'text-destructive' : 'text-foreground'}`}>
        {value}{suffix}
      </span>
      {subValue && (
        <span className={`text-sm font-medium ${isPositive === true ? 'text-green-500/80' : isPositive === false ? 'text-red-500/80' : highlight ? 'text-destructive/80' : 'text-muted-foreground'}`}>
          {subValue}
        </span>
      )}
    </div>
  </div>
);

const StrategyStats = ({ stats }) => {
  if (!stats) return null;

  return (
    <Card className="shadow-sm border-border">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold tracking-tight">Statistiche Strategia</h3>
          {stats.totalTrades > 0 && (
            <Badge variant={stats.netProfit > 0 ? "default" : "destructive"} className="px-3 py-1">
              {stats.netProfit > 0 ? 'Strategia Profittevole' : 'Strategia in Perdita'}
            </Badge>
          )}
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          <StatItem 
            label="Capitale Iniziale" 
            value={formatCurrency(stats.initialCapital)} 
          />
          <StatItem 
            label="Capitale Finale" 
            value={formatCurrency(stats.finalCapital)} 
            isPositive={stats.finalCapital > stats.initialCapital ? true : stats.finalCapital < stats.initialCapital ? false : null}
          />
          <StatItem 
            label="Profitto Totale" 
            value={formatCurrency(stats.netProfit)} 
            subValue={`(${formatPercent(stats.netProfitPercent)})`}
            isPositive={stats.netProfit > 0 ? true : stats.netProfit < 0 ? false : null}
          />
          <StatItem 
            label="Drawdown Massimo" 
            value={formatCurrency(-stats.maxDrawdownValue)} 
            subValue={`(-${formatNumber(stats.maxDrawdownPercent)}%)`}
            isPositive={stats.maxDrawdownValue === 0 ? null : false}
          />
          <StatItem 
            label="Trade Eseguiti" 
            value={stats.totalTrades} 
          />
          <StatItem 
            label="Trade Saltati" 
            value={stats.skippedTrades} 
            subValue={stats.skippedReason ? `(${stats.skippedReason})` : null}
            highlight={stats.skippedTrades > 0}
          />
          <StatItem 
            label="Win Rate" 
            value={formatNumber(stats.winRate)} 
            suffix="%"
            isPositive={stats.winRate >= 50 ? true : stats.winRate > 0 ? false : null}
          />
          <StatItem 
            label="Vinte / Perse" 
            value={`${stats.winningTrades} / ${stats.losingTrades}`} 
          />
          <StatItem 
            label="Profitto Medio/Trade" 
            value={formatCurrency(stats.avgProfit)} 
            isPositive={stats.avgProfit > 0 ? true : stats.avgProfit < 0 ? false : null}
          />
          <StatItem 
            label="Fattore di Profitto" 
            value={stats.profitFactor === Infinity ? '∞' : formatNumber(stats.profitFactor)} 
            isPositive={stats.profitFactor > 1 ? true : stats.profitFactor < 1 && stats.profitFactor > 0 ? false : null}
          />
          <StatItem 
            label="Durata Media Trade" 
            value={formatNumber(stats.avgDuration)} 
            suffix=" gg"
          />
          <StatItem 
            label="Massimo Equity" 
            value={formatCurrency(stats.peakEquity)} 
            isPositive={true}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default StrategyStats;
