
import React, { useState } from 'react';
import { Settings2, RotateCcw, Check, ChevronDown, ChevronUp, AlertCircle } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const OscillatorSettings = ({ 
  settings, 
  updateSetting, 
  resetOscillator, 
  applySettings, 
  validateRange 
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleBlur = (oscillator, param) => {
    const validatedValue = validateRange(oscillator, param, settings[oscillator][param]);
    updateSetting(oscillator, param, validatedValue);
  };

  const handleChange = (oscillator, param, value) => {
    updateSetting(oscillator, param, value);
  };

  const renderSection = (title, oscillator, fields, accentColor) => (
    <div className={`osc-panel-section border border-border/50 rounded-xl p-4 bg-card/50 transition-colors hover:bg-card/80`} style={{ '--accent-color': `var(${accentColor})` }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: `hsl(var(${accentColor}))` }} />
          {title}
        </h3>
        <Button 
          variant="ghost" 
          size="sm" 
          className="h-8 text-xs text-muted-foreground hover:text-foreground"
          onClick={() => resetOscillator(oscillator)}
        >
          <RotateCcw className="w-3 h-3 mr-1.5" />
          Reset
        </Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {fields.map(field => (
          <div key={field.param} className="space-y-1.5">
            <Label className="text-xs text-muted-foreground flex justify-between">
              {field.label}
              {field.type !== 'select' && <span className="opacity-50 text-[10px]">({field.min}-{field.max})</span>}
            </Label>
            {field.type === 'select' ? (
              <Select 
                value={settings[oscillator][field.param]} 
                onValueChange={(val) => handleChange(oscillator, field.param, val)}
              >
                <SelectTrigger className="h-9 focus-visible:ring-1 focus-visible:ring-offset-0" style={{ '--tw-ring-color': `hsl(var(${accentColor}))` }}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {field.options.map(opt => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ) : (
              <Input 
                type="number" 
                min={field.min} 
                max={field.max}
                step={field.step || 1}
                value={settings[oscillator][field.param]}
                onChange={(e) => handleChange(oscillator, field.param, e.target.value)}
                onBlur={() => handleBlur(oscillator, field.param)}
                className="h-9 focus-visible:ring-1 focus-visible:ring-offset-0"
                style={{ '--tw-ring-color': `hsl(var(${accentColor}))` }}
              />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Collapsible
      open={isOpen}
      onOpenChange={setIsOpen}
      className="bg-card border border-border rounded-xl shadow-sm mb-6 overflow-hidden transition-all duration-300"
    >
      <div className="flex items-center justify-between p-4 bg-muted/30">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
            <Settings2 className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h2 className="text-sm font-semibold">Oscillator Settings</h2>
            <p className="text-xs text-muted-foreground hidden sm:block">Configure parameters for technical indicators</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button 
            variant="default" 
            size="sm" 
            className="h-9 active:scale-[0.98] transition-transform"
            onClick={(e) => {
              e.stopPropagation();
              applySettings();
            }}
          >
            <Check className="w-4 h-4 mr-1.5" />
            Apply Settings
          </Button>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="sm" className="w-9 p-0">
              {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </Button>
          </CollapsibleTrigger>
        </div>
      </div>

      <CollapsibleContent className="p-4 pt-0">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mt-4">
          {renderSection('Moving Average', 'ma200', [
            { label: 'Period', param: 'period', min: 50, max: 500 },
            { label: 'Type', param: 'type', type: 'select', options: [{ value: 'SMA', label: 'Simple (SMA)' }, { value: 'EMA', label: 'Exponential (EMA)' }] },
          ], '--ma200')}

          {renderSection('RSI', 'rsi', [
            { label: 'Period', param: 'period', min: 5, max: 50 },
            { label: 'Overbought', param: 'overbought', min: 50, max: 90 },
            { label: 'Oversold', param: 'oversold', min: 10, max: 50 },
          ], '--osc-rsi')}

          {renderSection('MACD', 'macd', [
            { label: 'Fast EMA', param: 'fastEMA', min: 5, max: 20 },
            { label: 'Slow EMA', param: 'slowEMA', min: 20, max: 50 },
            { label: 'Signal Line', param: 'signalLine', min: 5, max: 15 },
          ], '--osc-macd')}

          {renderSection('Bollinger Bands', 'bollingerBands', [
            { label: 'Period', param: 'period', min: 10, max: 50 },
            { label: 'Std. Deviation', param: 'stdDev', min: 1, max: 3, step: 0.1 },
          ], '--osc-bb')}

          {renderSection('Parabolic SAR', 'sar', [
            { label: 'Acceleration Factor', param: 'accelerationFactor', min: 0.01, max: 0.05, step: 0.01 },
            { label: 'Max AF', param: 'maxAccelerationFactor', min: 0.1, max: 0.5, step: 0.1 },
          ], '--osc-sar')}
        </div>
        
        <div className="mt-4 flex items-center justify-between p-3 rounded-lg bg-blue-500/10 border border-blue-500/20 text-sm">
          <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400">
            <AlertCircle className="w-4 h-4" />
            <span>Click <strong>Apply Settings</strong> to refresh the charts with your new parameters.</span>
          </div>
        </div>
      </CollapsibleContent>
    </Collapsible>
  );
};

export default OscillatorSettings;
