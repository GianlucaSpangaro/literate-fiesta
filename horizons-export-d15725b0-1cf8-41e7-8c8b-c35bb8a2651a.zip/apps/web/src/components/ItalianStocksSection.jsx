
import React, { useState, useMemo, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, TrendingUp, ArrowRight, ChevronDown, ChevronUp } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

// Updated with verified Yahoo Finance symbols for Borsa Italiana
// Removed invalid/delisted symbols: EXOR.MI, CNHI.MI, RECORDATI.MI
const stocksData = [
  { symbol: 'ENEL.MI', name: 'Enel', sector: 'Energia' },
  { symbol: 'ENI.MI', name: 'Eni', sector: 'Energia' },
  { symbol: 'PST.MI', name: 'Poste Italiane', sector: 'Servizi Postali' },
  { symbol: 'UCG.MI', name: 'UniCredit', sector: 'Banche' },
  { symbol: 'ISP.MI', name: 'Intesa Sanpaolo', sector: 'Banche' },
  { symbol: 'MB.MI', name: 'Mediobanca', sector: 'Banche' },
  { symbol: 'BAMI.MI', name: 'Banco BPM', sector: 'Banche' },
  { symbol: 'BPE.MI', name: 'BPER Banca', sector: 'Banche' },
  { symbol: 'FBK.MI', name: 'FinecoBank', sector: 'Banche' },
  { symbol: 'BMPS.MI', name: 'Banca Monte dei Paschi', sector: 'Banche' },
  { symbol: 'TIT.MI', name: 'Telecom Italia', sector: 'Telecomunicazioni' },
  { symbol: 'INW.MI', name: 'Inwit', sector: 'Telecomunicazioni' },
  { symbol: 'STM.MI', name: 'STMicroelectronics', sector: 'Semiconduttori' },
  { symbol: 'UNI.MI', name: 'Unipol', sector: 'Assicurazioni' },
  { symbol: 'G.MI', name: 'Generali', sector: 'Assicurazioni' },
  { symbol: 'STLA.MI', name: 'Stellantis', sector: 'Automotive' },
  { symbol: 'RACE.MI', name: 'Ferrari', sector: 'Automotive' },
  { symbol: 'PIRC.MI', name: 'Pirelli', sector: 'Automotive' },
  { symbol: 'IVG.MI', name: 'Iveco Group', sector: 'Automotive' },
  { symbol: 'MONC.MI', name: 'Moncler', sector: 'Lusso' },
  { symbol: 'CPR.MI', name: 'Campari', sector: 'Food & Beverage' },
  { symbol: 'PRY.MI', name: 'Prysmian', sector: 'Infrastrutture' },
  { symbol: 'SPM.MI', name: 'Saipem', sector: 'Energia' },
  { symbol: 'TEN.MI', name: 'Tenaris', sector: 'Energia' },
  { symbol: 'TRN.MI', name: 'Terna', sector: 'Energia' },
  { symbol: 'SRG.MI', name: 'Snam', sector: 'Energia' },
  { symbol: 'A2A.MI', name: 'A2A', sector: 'Utilities' },
  { symbol: 'HER.MI', name: 'Hera', sector: 'Utilities' },
  { symbol: 'IG.MI', name: 'Italgas', sector: 'Utilities' },
  { symbol: 'DIA.MI', name: 'DiaSorin', sector: 'Healthcare' },
  { symbol: 'AMP.MI', name: 'Amplifon', sector: 'Healthcare' },
  { symbol: 'NEXI.MI', name: 'Nexi', sector: 'Fintech' },
  { symbol: 'LDO.MI', name: 'Leonardo', sector: 'Industriale' }
];

const ItalianStocksSection = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [openSectors, setOpenSectors] = useState({});

  // Filter and group stocks
  const groupedStocks = useMemo(() => {
    const filtered = stocksData.filter(stock => 
      stock.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      stock.symbol.toLowerCase().includes(searchQuery.toLowerCase())
    );

    const groups = {};
    filtered.forEach(stock => {
      if (!groups[stock.sector]) {
        groups[stock.sector] = [];
      }
      groups[stock.sector].push(stock);
    });

    // Sort sectors alphabetically
    return Object.keys(groups).sort().reduce((acc, key) => {
      acc[key] = groups[key];
      return acc;
    }, {});
  }, [searchQuery]);

  // Initialize all sectors as open, and auto-expand when searching
  useEffect(() => {
    const allSectors = {};
    Object.keys(groupedStocks).forEach(sector => {
      allSectors[sector] = true;
    });
    setOpenSectors(allSectors);
  }, [searchQuery, groupedStocks]);

  const toggleSector = (sector) => {
    setOpenSectors(prev => ({
      ...prev,
      [sector]: !prev[sector]
    }));
  };

  const handleStockClick = (symbol) => {
    navigate(`/analysis?symbol=${symbol}`);
  };

  const hasResults = Object.keys(groupedStocks).length > 0;

  return (
    <section className="py-16">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
        <div>
          <h2 className="text-2xl md:text-3xl font-semibold tracking-tight mb-2">
            FTSE MIB Components
          </h2>
          <p className="text-muted-foreground">
            Explore all major Italian stocks organized by sector
          </p>
        </div>
        
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search company or symbol..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-background border-border"
          />
        </div>
      </div>

      {!hasResults ? (
        <div className="text-center py-20 bg-card/30 rounded-2xl border border-border border-dashed">
          <Search className="w-10 h-10 text-muted-foreground mx-auto mb-4 opacity-50" />
          <h3 className="text-lg font-medium mb-1">No stocks found</h3>
          <p className="text-muted-foreground">
            We couldn't find any stocks matching "{searchQuery}"
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {Object.entries(groupedStocks).map(([sector, stocks]) => (
            <Collapsible
              key={sector}
              open={openSectors[sector]}
              onOpenChange={() => toggleSector(sector)}
              className="space-y-4"
            >
              <div className="flex items-center justify-between border-b border-border pb-2">
                <div className="flex items-center gap-3">
                  <h3 className="text-xl font-medium tracking-tight">{sector}</h3>
                  <span className="px-2.5 py-0.5 rounded-full bg-secondary text-secondary-foreground text-xs font-medium">
                    {stocks.length}
                  </span>
                </div>
                <CollapsibleTrigger className="p-2 hover:bg-muted rounded-md transition-colors">
                  {openSectors[sector] ? (
                    <ChevronUp className="w-5 h-5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-muted-foreground" />
                  )}
                </CollapsibleTrigger>
              </div>
              
              <CollapsibleContent className="pt-2">
                <div className="stock-grid">
                  {stocks.map((stock) => (
                    <div
                      key={stock.symbol}
                      onClick={() => handleStockClick(stock.symbol)}
                      className="stock-card group p-5 flex flex-col h-full"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                          <TrendingUp className="w-5 h-5 text-primary" />
                        </div>
                        <ArrowRight className="w-5 h-5 text-muted-foreground opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                      </div>
                      
                      <div className="mt-auto">
                        <h4 className="text-xl font-semibold mb-1 tracking-tight">{stock.symbol}</h4>
                        <p className="text-sm text-muted-foreground font-medium line-clamp-1">
                          {stock.name}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CollapsibleContent>
            </Collapsible>
          ))}
        </div>
      )}
    </section>
  );
};

export default ItalianStocksSection;
