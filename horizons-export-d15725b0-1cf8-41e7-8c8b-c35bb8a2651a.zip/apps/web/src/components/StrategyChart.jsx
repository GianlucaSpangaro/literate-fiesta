
import React, { useMemo, useState, useRef, useEffect } from 'react';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceDot
} from 'recharts';
import { format } from 'date-fns';
import { ArrowUpDown, ArrowUp, ArrowDown, ArrowLeftRight, ArrowLeft, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import EquityLineChart from './EquityLineChart';

const StrategyChart = ({ 
  data, 
  ma200, 
  sar,
  trades,
  equityLine,
  initialCapital,
  symbol = ''
}) => {
  const containerRef = useRef(null);
  const chartAreaRef = useRef(null);

  const [viewState, setViewState] = useState({
    startIndex: 0,
    endIndex: 0,
    minPrice: 0,
    maxPrice: 100,
    isInitialized: false
  });

  const [dragState, setDragState] = useState({
    isDragging: false,
    startX: 0,
    startY: 0,
    initialStartIndex: 0,
    initialEndIndex: 0,
    initialMinPrice: 0,
    initialMaxPrice: 100
  });

  const [hoveredCandleIndex, setHoveredCandleIndex] = useState(null);
  const [mousePos, setMousePos] = useState({ x: null, y: null });
  const [hoveredPrice, setHoveredPrice] = useState(null);

  const chartData = useMemo(() => {
    if (!data || data.length === 0) return [];

    return data.map((candle, index) => {
      const ma200Data = ma200?.find(m => new Date(m.timestamp).getTime() === new Date(candle.timestamp).getTime());
      const sarData = sar?.find(s => new Date(s.timestamp).getTime() === new Date(candle.timestamp).getTime());

      return {
        index,
        timestamp: candle.timestamp,
        open: Number(candle.open),
        high: Number(candle.high),
        low: Number(candle.low),
        close: Number(candle.close),
        priceRange: [Number(candle.low), Number(candle.high)],
        ma200: ma200Data?.value ? Number(ma200Data.value) : null,
        sar: sarData?.value ? Number(sarData.value) : null,
        isBullish: Number(candle.close) >= Number(candle.open)
      };
    });
  }, [data, ma200, sar]);

  const tradeDots = useMemo(() => {
    if (!chartData || !trades) return [];
    const dots = [];
    
    // Filter out skipped trades due to insufficient capital
    const executedTrades = trades.filter(t => t.status !== 'skipped');
    
    executedTrades.forEach(trade => {
      const entryIndex = chartData.findIndex(c => new Date(c.timestamp).getTime() === new Date(trade.entryDate).getTime());
      const exitIndex = chartData.findIndex(c => new Date(c.timestamp).getTime() === new Date(trade.exitDate).getTime());
      
      if (entryIndex !== -1) {
        const candle = chartData[entryIndex];
        const y = candle.low - (candle.high - candle.low) * 0.5;
        dots.push({ type: 'buy', x: entryIndex, y });
      }
      
      if (exitIndex !== -1) {
        const candle = chartData[exitIndex];
        const y = candle.high + (candle.high - candle.low) * 0.5;
        dots.push({ type: 'sell', x: exitIndex, y });
      }
    });
    
    return dots;
  }, [chartData, trades]);

  const globalBounds = useMemo(() => {
    if (!chartData || chartData.length === 0) return { min: 0, max: 100 };
    let minP = Infinity;
    let maxP = -Infinity;
    for (let i = 0; i < chartData.length; i++) {
      const d = chartData[i];
      if (d.low < minP) minP = d.low;
      if (d.high > maxP) maxP = d.high;
      if (d.ma200 && d.ma200 < minP) minP = d.ma200;
      if (d.ma200 && d.ma200 > maxP) maxP = d.ma200;
    }
    if (minP === Infinity) { minP = 0; maxP = 100; } 
    else { const padding = (maxP - minP) * 0.05; minP -= padding; maxP += padding; }
    return { min: minP, max: maxP };
  }, [chartData]);

  useEffect(() => {
    if (chartData && chartData.length > 0) {
      setViewState({
        startIndex: 0,
        endIndex: chartData.length - 1,
        minPrice: globalBounds.min,
        maxPrice: globalBounds.max,
        isInitialized: true
      });
    }
  }, [chartData, globalBounds]);

  const startIdx = Math.max(0, Math.floor(viewState.startIndex));
  const endIdx = Math.min((chartData?.length || 1) - 1, Math.ceil(viewState.endIndex));

  const visibleData = useMemo(() => {
    if (!chartData || !viewState.isInitialized) return [];
    return chartData.slice(startIdx, endIdx + 1);
  }, [chartData, startIdx, endIdx, viewState.isInitialized]);

  const handleMouseDown = (e) => {
    if (!viewState.isInitialized) return;
    setDragState({
      isDragging: true,
      startX: e.clientX,
      startY: e.clientY,
      initialStartIndex: viewState.startIndex,
      initialEndIndex: viewState.endIndex,
      initialMinPrice: viewState.minPrice,
      initialMaxPrice: viewState.maxPrice
    });
  };

  const handleMouseMove = (e) => {
    if (!containerRef.current || !chartData.length) return;

    if (dragState.isDragging) {
      const deltaX = e.clientX - dragState.startX;
      const deltaY = e.clientY - dragState.startY;
      const width = containerRef.current.clientWidth;
      const height = containerRef.current.clientHeight;

      if (width === 0 || height === 0) return;

      const candlesVisible = dragState.initialEndIndex - dragState.initialStartIndex;
      const candleWidth = width / Math.max(1, candlesVisible);
      const indexDelta = -Math.round(deltaX / candleWidth);
      
      let newStart = dragState.initialStartIndex + indexDelta;
      let newEnd = dragState.initialEndIndex + indexDelta;

      if (candlesVisible >= chartData.length - 1) {
        newStart = 0;
        newEnd = chartData.length - 1;
      } else {
        if (newStart < 0) { newStart = 0; newEnd = candlesVisible; }
        if (newEnd > chartData.length - 1) { newEnd = chartData.length - 1; newStart = chartData.length - 1 - candlesVisible; }
      }

      const priceRange = dragState.initialMaxPrice - dragState.initialMinPrice;
      const priceUnits = (deltaY * priceRange) / height;
      
      let newMinPrice = dragState.initialMinPrice + priceUnits;
      let newMaxPrice = dragState.initialMaxPrice + priceUnits;

      if (newMinPrice < globalBounds.min) {
        newMinPrice = globalBounds.min;
        newMaxPrice = newMinPrice + priceRange;
      }
      if (newMaxPrice > globalBounds.max) {
        newMaxPrice = globalBounds.max;
        newMinPrice = newMaxPrice - priceRange;
      }

      setViewState(prev => ({
        ...prev,
        startIndex: newStart,
        endIndex: newEnd,
        minPrice: newMinPrice,
        maxPrice: newMaxPrice
      }));
      return;
    }

    if (chartAreaRef.current && visibleData.length > 0) {
      const rect = chartAreaRef.current.getBoundingClientRect();
      const mouseX = e.clientX;
      const mouseY = e.clientY;
      const chartLeftOffset = rect.left;
      const chartTopOffset = rect.top;
      const chartWidth = rect.width;
      const chartHeight = rect.height;

      if (mouseX >= chartLeftOffset && mouseX <= chartLeftOffset + chartWidth &&
          mouseY >= chartTopOffset && mouseY <= chartTopOffset + chartHeight) {
        const relativeX = mouseX - chartLeftOffset;
        const relativeY = mouseY - chartTopOffset;
        const candleWidth = chartWidth / visibleData.length;
        let candleIndex = Math.floor(relativeX / candleWidth);
        candleIndex = Math.max(0, Math.min(candleIndex, visibleData.length - 1));
        
        setHoveredCandleIndex(candleIndex);
        setMousePos({ x: relativeX, y: relativeY });

        const topMargin = 10;
        const effectiveHeight = chartHeight - topMargin;
        const yPos = relativeY - topMargin;
        const clampedY = Math.max(0, Math.min(yPos, effectiveHeight));
        const priceRange = viewState.maxPrice - viewState.minPrice;
        const calcPrice = viewState.maxPrice - (clampedY / effectiveHeight) * priceRange;
        setHoveredPrice(calcPrice);
      } else {
        setHoveredCandleIndex(null);
        setMousePos({ x: null, y: null });
        setHoveredPrice(null);
      }
    }
  };

  const handleMouseUp = () => setDragState(prev => ({ ...prev, isDragging: false }));
  const handleMouseLeave = () => {
    setDragState(prev => ({ ...prev, isDragging: false }));
    setHoveredCandleIndex(null);
    setMousePos({ x: null, y: null });
    setHoveredPrice(null);
  };
  const handleDoubleClick = () => {
    if (chartData && chartData.length > 0) {
      setViewState({
        startIndex: 0,
        endIndex: chartData.length - 1,
        minPrice: globalBounds.min,
        maxPrice: globalBounds.max,
        isInitialized: true
      });
    }
  };

  const handleYZoom = (direction) => {
    setViewState(prev => {
      if (!prev.isInitialized) return prev;
      const currentRange = prev.maxPrice - prev.minPrice;
      const center = prev.minPrice + currentRange / 2;
      const factor = direction === 'in' ? 0.833 : 1.2;
      let newRange = currentRange * factor;
      if (newRange < 0.0001) newRange = 0.0001;
      let newMin = center - newRange / 2;
      let newMax = center + newRange / 2;
      if (newMin < globalBounds.min) newMin = globalBounds.min;
      if (newMax > globalBounds.max) newMax = globalBounds.max;
      if (newMin >= newMax) return prev;
      return { ...prev, minPrice: newMin, maxPrice: newMax };
    });
  };

  const handleXZoom = (direction) => {
    setViewState(prev => {
      if (!prev.isInitialized || !chartData.length) return prev;
      const currentStart = prev.startIndex;
      const currentEnd = prev.endIndex;
      let currentWidth = currentEnd - currentStart;
      if (currentWidth < 1) currentWidth = 1;
      const center = currentStart + currentWidth / 2;
      const factor = 1.2;
      let newWidth = direction === 'in' ? currentWidth / factor : currentWidth * factor;
      const minWidth = 5;
      const maxWidth = chartData.length - 1;
      if (newWidth < minWidth) newWidth = minWidth;
      if (newWidth > maxWidth) newWidth = maxWidth;
      let newStart = center - newWidth / 2;
      let newEnd = center + newWidth / 2;
      if (newStart < 0) { newStart = 0; newEnd = Math.min(newWidth, maxWidth); }
      if (newEnd > maxWidth) { newEnd = maxWidth; newStart = Math.max(0, maxWidth - newWidth); }
      return { ...prev, startIndex: newStart, endIndex: newEnd };
    });
  };

  const xTicks = useMemo(() => {
    if (!viewState.isInitialized || !chartData.length) return [];
    const numTicks = 6;
    const step = Math.max(1, Math.floor((endIdx - startIdx) / (numTicks - 1)));
    const ticks = [];
    for (let i = startIdx; i <= endIdx; i += step) ticks.push(i);
    if (ticks[ticks.length - 1] !== endIdx) ticks[ticks.length - 1] = endIdx;
    return ticks;
  }, [startIdx, endIdx, viewState.isInitialized, chartData.length]);

  const formatPrice = (value) => value ? `€${Number(value).toFixed(2).replace('.', ',')}` : '';
  const formatXAxis = (index) => {
    const candle = chartData[index];
    if (!candle) return '';
    const date = new Date(candle.timestamp);
    return format(date, 'MMM dd');
  };

  const CustomCandlestick = (props) => {
    const { x, y, width, height, payload } = props;
    if (!payload) return null;
    const { open, close, high, low, isBullish } = payload;
    const color = isBullish ? 'hsl(var(--bullish, 142.1 76.2% 36.3%))' : 'hsl(var(--bearish, 346.8 77.2% 49.8%))';
    const wickX = x + width / 2;
    const range = high - low;
    if (range === 0) return <line x1={x} y1={y} x2={x + width} y2={y} stroke={color} strokeWidth={1} />;
    const openY = y + height * ((high - open) / range);
    const closeY = y + height * ((high - close) / range);
    const bodyTop = Math.min(openY, closeY);
    const bodyBottom = Math.max(openY, closeY);
    const bodyHeight = Math.max(1, bodyBottom - bodyTop);

    return (
      <g>
        <line x1={wickX} y1={y} x2={wickX} y2={bodyTop} stroke={color} strokeWidth={1} />
        <line x1={wickX} y1={bodyBottom} x2={wickX} y2={y + height} stroke={color} strokeWidth={1} />
        <rect x={x} y={bodyTop} width={width} height={bodyHeight} fill={color} stroke={color} strokeWidth={1} />
      </g>
    );
  };

  const CustomBuySignal = (props) => {
    const { cx, cy } = props;
    return (
      <g transform={`translate(${cx},${cy + 15})`}>
        <path d="M-6,0 L0,-10 L6,0 Z" fill="#22c55e" />
        <rect x="-2" y="0" width="4" height="8" fill="#22c55e" />
      </g>
    );
  };

  const CustomSellSignal = (props) => {
    const { cx, cy } = props;
    return (
      <g transform={`translate(${cx},${cy - 15})`}>
        <path d="M-6,0 L0,10 L6,0 Z" fill="#ef4444" />
        <rect x="-2" y="-8" width="4" height="8" fill="#ef4444" />
      </g>
    );
  };

  if (!chartData || chartData.length === 0 || !viewState.isInitialized) {
    return (
      <div className="flex items-center justify-center h-96 bg-card rounded-xl border border-border">
        <p className="text-muted-foreground">Esegui la strategia per visualizzare il grafico</p>
      </div>
    );
  }

  return (
    <div 
      className={`space-y-6 relative ${dragState.isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
      style={{ userSelect: 'none' }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseLeave}
      onDoubleClick={handleDoubleClick}
      ref={containerRef}
    >
      <div className="bg-card rounded-xl border border-border relative shadow-sm w-full flex flex-col p-6">
        <div className="flex items-center justify-between mb-4 shrink-0">
          <div className="flex items-center gap-4">
            <h3 className="text-lg font-semibold" style={{ letterSpacing: '-0.01em' }}>
              Chart Strategia
            </h3>
            <div className="flex items-center gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8 transition-all duration-200 active:scale-95" aria-label="Y-Axis Zoom">
                    <ArrowUpDown className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onClick={() => handleYZoom('in')} className="cursor-pointer">
                    <ArrowUp className="h-4 w-4 mr-2" /> Zoom In (Y)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleYZoom('out')} className="cursor-pointer">
                    <ArrowDown className="h-4 w-4 mr-2" /> Zoom Out (Y)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="icon" className="h-8 w-8 transition-all duration-200 active:scale-95" aria-label="X-Axis Zoom">
                    <ArrowLeftRight className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onClick={() => handleXZoom('in')} className="cursor-pointer">
                    <ArrowLeft className="h-4 w-4 mr-2" /> Zoom In (X)
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleXZoom('out')} className="cursor-pointer">
                    <ArrowRight className="h-4 w-4 mr-2" /> Zoom Out (X)
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        <div className="flex-1 min-h-0 w-full overflow-hidden pointer-events-none relative" ref={chartAreaRef}>
          {mousePos.x !== null && mousePos.y !== null && !dragState.isDragging && (
            <>
              <div className="absolute top-0 bottom-0 pointer-events-none z-10" style={{ left: mousePos.x, width: '1px', borderLeft: '1px dashed #888', opacity: 0.7 }} />
              <div className="absolute left-0 right-0 pointer-events-none z-10" style={{ top: mousePos.y, height: '1px', borderTop: '1px dashed #888', opacity: 0.7 }} />
              {hoveredPrice !== null && (
                <div className="absolute right-0 z-30 bg-[#222] text-white border border-[#444] text-xs px-2 py-1 rounded-sm pointer-events-none shadow-sm" style={{ top: mousePos.y, transform: 'translateY(-50%)' }}>
                  {formatPrice(hoveredPrice)}
                </div>
              )}
            </>
          )}

          <ResponsiveContainer width="100%" height={450}>
            <ComposedChart data={visibleData} margin={{ top: 10, right: 40, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="5 5" stroke="hsl(var(--chart-grid))" strokeOpacity={0.25} strokeWidth={1} />
              {xTicks.map(tick => <ReferenceLine key={`ref-${tick}`} x={tick} stroke="hsl(var(--chart-grid))" strokeOpacity={0.25} strokeDasharray="5 5" strokeWidth={1} />)}
              
              <XAxis type="number" dataKey="index" domain={['dataMin', 'dataMax']} allowDecimals={false} tickFormatter={formatXAxis} stroke="hsl(var(--muted-foreground))" style={{ fontSize: '0.75rem' }} tickMargin={10} ticks={xTicks} allowDataOverflow />
              <YAxis domain={[viewState.minPrice, viewState.maxPrice]} stroke="hsl(var(--muted-foreground))" style={{ fontSize: '0.75rem' }} tickFormatter={formatPrice} tickMargin={10} tickCount={7} allowDataOverflow />
              
              <Tooltip cursor={false} isAnimationActive={false} content={() => null} />
              
              <Line type="monotone" dataKey="ma200" stroke="#f97316" strokeWidth={2} dot={false} name="MA200" connectNulls isAnimationActive={false} />
              
              <Bar dataKey="priceRange" shape={<CustomCandlestick />} name="Price" isAnimationActive={false} />

              {tradeDots.map((dot, i) => (
                <ReferenceDot 
                  key={`trade-dot-${i}`}
                  x={dot.x}
                  y={dot.y}
                  shape={dot.type === 'buy' ? <CustomBuySignal /> : <CustomSellSignal />}
                  isFront={true}
                />
              ))}
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border relative shadow-sm w-full flex flex-col p-6">
        <h3 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">SAR Parabolico</h3>
        <div className="flex-1 min-h-0 w-full overflow-hidden pointer-events-none">
          <ResponsiveContainer width="100%" height={150}>
            <ComposedChart data={visibleData} margin={{ top: 10, right: 40, left: 0, bottom: 0 }}>
              <CartesianGrid vertical={false} strokeDasharray="5 5" stroke="hsl(var(--chart-grid))" strokeOpacity={0.25} strokeWidth={1} />
              <XAxis type="number" dataKey="index" domain={['dataMin', 'dataMax']} allowDecimals={false} tickFormatter={formatXAxis} stroke="hsl(var(--muted-foreground))" style={{ fontSize: '0.75rem' }} tickMargin={10} ticks={xTicks} allowDataOverflow />
              <YAxis domain={['auto', 'auto']} stroke="hsl(var(--muted-foreground))" style={{ fontSize: '0.75rem' }} tickFormatter={formatPrice} tickMargin={10} tickCount={5} />
              <Line type="monotone" dataKey="sar" stroke="#ef4444" strokeWidth={2} dot={false} name="SAR" connectNulls isAnimationActive={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-card rounded-xl border border-border relative shadow-sm w-full flex flex-col p-6">
        <h3 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">Equity Line</h3>
        <EquityLineChart data={equityLine} initialCapital={initialCapital} />
      </div>
    </div>
  );
};

export default StrategyChart;
