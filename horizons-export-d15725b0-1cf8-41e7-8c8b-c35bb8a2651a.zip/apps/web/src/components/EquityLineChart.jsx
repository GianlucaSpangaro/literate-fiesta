
import React, { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine
} from 'recharts';
import { format } from 'date-fns';

const EquityLineChart = ({ data, initialCapital }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('it-IT', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(value);
  };

  const formatXAxis = (timestamp) => {
    return format(new Date(timestamp), 'MMM yy');
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      const currentCapital = payload[0].value;
      const profit = currentCapital - initialCapital;
      const profitPercent = (profit / initialCapital) * 100;
      const isProfit = profit >= 0;

      return (
        <div className="bg-card border border-border p-3 rounded-lg shadow-lg text-sm">
          <p className="font-medium mb-2 text-foreground">{format(new Date(label), 'dd MMM yyyy')}</p>
          <div className="flex flex-col gap-1">
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">Equity:</span>
              <span className="font-bold text-foreground">{formatCurrency(currentCapital)}</span>
            </div>
            <div className="flex justify-between gap-4">
              <span className="text-muted-foreground">P/L:</span>
              <span className={`font-medium ${isProfit ? 'text-green-500' : 'text-red-500'}`}>
                {isProfit ? '+' : ''}{formatCurrency(profit)} ({isProfit ? '+' : ''}{profitPercent.toFixed(2)}%)
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const yDomain = useMemo(() => {
    if (!data || data.length === 0) return [0, 'auto'];
    const min = Math.min(...data.map(d => d.capital));
    const max = Math.max(...data.map(d => d.capital));
    const padding = (max - min) * 0.1;
    return [Math.max(0, min - padding), max + padding];
  }, [data]);

  if (!data || data.length === 0) {
    return (
      <div className="flex items-center justify-center h-48 bg-muted/20 rounded-xl border border-border">
        <p className="text-muted-foreground text-sm">Nessun dato equity disponibile</p>
      </div>
    );
  }

  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart
          data={data}
          margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
        >
          <defs>
            <linearGradient id="colorCapital" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
              <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--chart-grid))" strokeOpacity={0.3} />
          <XAxis 
            dataKey="timestamp" 
            tickFormatter={formatXAxis} 
            stroke="hsl(var(--muted-foreground))" 
            fontSize={12}
            tickMargin={10}
            minTickGap={30}
          />
          <YAxis 
            domain={yDomain}
            tickFormatter={(val) => `€${(val/1000).toFixed(1)}k`}
            stroke="hsl(var(--muted-foreground))" 
            fontSize={12}
            width={60}
          />
          <Tooltip content={<CustomTooltip />} />
          <ReferenceLine y={initialCapital} stroke="hsl(var(--muted-foreground))" strokeDasharray="3 3" opacity={0.5} />
          <Area 
            type="stepAfter" 
            dataKey="capital" 
            stroke="#3b82f6" 
            strokeWidth={2}
            fillOpacity={1} 
            fill="url(#colorCapital)" 
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};

export default EquityLineChart;
