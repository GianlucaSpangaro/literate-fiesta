
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Search, TrendingUp, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ItalianStocksSection from '@/components/ItalianStocksSection';

const popularSymbols = [
  { symbol: 'AAPL', name: 'Apple Inc.', market: 'USA' },
  { symbol: 'MSFT', name: 'Microsoft Corporation', market: 'USA' },
  { symbol: 'GOOGL', name: 'Alphabet Inc.', market: 'USA' },
  { symbol: 'AMZN', name: 'Amazon.com Inc.', market: 'USA' },
  { symbol: 'TSLA', name: 'Tesla Inc.', market: 'USA' },
  { symbol: 'FTSEMIB.MI', name: 'FTSE MIB Index', market: 'Italy' },
  { symbol: '^GDAXI', name: 'DAX Index', market: 'Europe' },
  { symbol: 'SPY', name: 'S&P 500 ETF', market: 'USA' },
  { symbol: 'QQQ', name: 'Nasdaq 100 ETF', market: 'USA' },
  { symbol: 'DIA', name: 'Dow Jones ETF', market: 'USA' }
];

const markets = ['All Markets', 'USA', 'Italy', 'Europe'];

const HomePage = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMarket, setSelectedMarket] = useState('All Markets');
  const [recentSearches, setRecentSearches] = useState([]);

  useEffect(() => {
    const stored = localStorage.getItem('recentSearches');
    if (stored) {
      try {
        setRecentSearches(JSON.parse(stored));
      } catch (e) {
        setRecentSearches([]);
      }
    }
  }, []);

  const filteredSymbols = popularSymbols.filter(item => {
    const matchesSearch = searchQuery === '' || 
      item.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.name.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesMarket = selectedMarket === 'All Markets' || item.market === selectedMarket;
    
    return matchesSearch && matchesMarket;
  });

  const handleViewAnalysis = (symbol, name, market) => {
    const newSearch = { symbol, name, market, timestamp: Date.now() };
    const updated = [newSearch, ...recentSearches.filter(s => s.symbol !== symbol)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('recentSearches', JSON.stringify(updated));
    navigate(`/analysis?symbol=${symbol}`);
  };

  return (
    <>
      <Helmet>
        <title>TechAnalysis Pro - Professional Stock Technical Analysis</title>
        <meta name="description" content="Advanced technical analysis platform for stocks, ETFs, and indices. Real-time charts with RSI, MACD, Bollinger Bands, and more." />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
            <div className="max-w-5xl mx-auto">
              <div className="text-center mb-12">
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary/10 rounded-full mb-6">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">Professional Technical Analysis</span>
                </div>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6" style={{ letterSpacing: '-0.02em', textWrap: 'balance' }}>
                  Analyze stocks with advanced technical indicators
                </h1>
                <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
                  Get real-time technical analysis with candlestick charts, RSI, MACD, Bollinger Bands, and Parabolic SAR for any stock, ETF, or index.
                </p>
              </div>

              <div className="bg-card rounded-2xl border border-border p-8 shadow-lg mb-16">
                <div className="space-y-6">
                  <div className="flex flex-col sm:flex-row gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                      <Input
                        type="search"
                        placeholder="Search symbol or company name..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-10 h-12 bg-background border-border text-foreground"
                      />
                    </div>
                    <Select value={selectedMarket} onValueChange={setSelectedMarket}>
                      <SelectTrigger className="w-full sm:w-48 h-12 bg-background border-border text-foreground">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {markets.map(market => (
                          <SelectItem key={market} value={market}>
                            {market}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  {recentSearches.length > 0 && searchQuery === '' && (
                    <div>
                      <h3 className="text-sm font-medium text-muted-foreground mb-3">Recent searches</h3>
                      <div className="space-y-2">
                        {recentSearches.map((item) => (
                          <button
                            key={item.symbol}
                            onClick={() => handleViewAnalysis(item.symbol, item.name, item.market)}
                            className="w-full flex items-center justify-between p-4 bg-muted/50 hover:bg-muted rounded-lg transition-all duration-200 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                <span className="text-sm font-semibold text-primary">{item.symbol.slice(0, 2)}</span>
                              </div>
                              <div className="text-left">
                                <div className="font-semibold">{item.symbol}</div>
                                <div className="text-sm text-muted-foreground">{item.name}</div>
                              </div>
                            </div>
                            <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-foreground group-hover:translate-x-1 transition-all duration-200" />
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground mb-3">
                      {searchQuery || selectedMarket !== 'All Markets' ? 'Search results' : 'Popular symbols'}
                    </h3>
                    <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                      {filteredSymbols.length > 0 ? (
                        filteredSymbols.map((item) => (
                          <div
                            key={item.symbol}
                            className="flex items-center justify-between p-4 bg-muted/50 hover:bg-muted rounded-lg transition-all duration-200 group"
                          >
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                <span className="text-sm font-semibold text-primary">{item.symbol.slice(0, 2)}</span>
                              </div>
                              <div>
                                <div className="font-semibold">{item.symbol}</div>
                                <div className="text-sm text-muted-foreground">{item.name}</div>
                              </div>
                            </div>
                            <Button
                              onClick={() => handleViewAnalysis(item.symbol, item.name, item.market)}
                              className="transition-all duration-200 active:scale-95"
                            >
                              View Analysis
                              <ArrowRight className="w-4 h-4 ml-2" />
                            </Button>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-8 text-muted-foreground">
                          No symbols found matching your search
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              <ItalianStocksSection />

              <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-card/50 rounded-xl border border-border p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Real-time data</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Access up-to-date market data with multiple timeframes from 5 minutes to monthly intervals.
                  </p>
                </div>

                <div className="bg-card/50 rounded-xl border border-border p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Advanced indicators</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Comprehensive technical analysis with RSI, MACD, Bollinger Bands, MA200, and Parabolic SAR.
                  </p>
                </div>

                <div className="bg-card/50 rounded-xl border border-border p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">Interactive charts</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Professional candlestick charts with zoom, pan, and detailed tooltips for precise analysis.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
