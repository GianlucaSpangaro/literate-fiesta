
import React, { useState, useEffect, useMemo } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { ArrowLeft, Loader2, Info, Maximize2, Minimize2, Activity } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import apiServerClient from '@/lib/apiServerClient';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import CandlestickChart from '@/components/CandlestickChart';
import RSIChart from '@/components/RSIChart';
import MACDChart from '@/components/MACDChart';
import DebugPanel from '@/components/DebugPanel';
import OscillatorSettings from '@/components/OscillatorSettings';
import StrategyExecutor from '@/components/StrategyExecutor';
import StrategyStats from '@/components/StrategyStats';
import TradesTable from '@/components/TradesTable';
import StrategyChart from '@/components/StrategyChart';
import { calculateStrategy } from '@/lib/StrategyCalculator';
import { useOscillatorSettings } from '@/hooks/useOscillatorSettings';
import { toast } from 'sonner';

const periods = [
  { value: '1m', label: '1 Month' },
  { value: '2m', label: '2 Months' },
  { value: '3m', label: '3 Months' },
  { value: '6m', label: '6 Months' },
  { value: '1y', label: '1 Year' },
  { value: '2y', label: '2 Years' },
  { value: '5y', label: '5 Years' }
];

const timeframes = [
  { value: '5m', label: '5 Minutes' },
  { value: '15m', label: '15 Minutes' },
  { value: '30m', label: '30 Minutes' },
  { value: '1h', label: '1 Hour' },
  { value: '1d', label: '1 Day' },
  { value: '1w', label: '1 Week' },
  { value: '1mo', label: '1 Month' }
];

const getPeriodDays = (period) => {
  const map = { '1m': 30, '2m': 60, '3m': 90, '6m': 180, '1y': 365, '2y': 730, '5y': 1825 };
  return map[period] || 365;
};

const isPeriodDisabled = (period, timeframe) => {
  const days = getPeriodDays(period);
  if (['5m', '15m', '30m'].includes(timeframe) && days > 60) return true;
  if (timeframe === '1h' && days > 730) return true;
  return false;
};

const getExtendedPeriod = (period) => {
  switch (period) {
    case '1m': return '3m';
    case '2m': return '3m';
    case '3m': return '6m';
    case '6m': return '1y';
    case '1y': return '2y';
    case '2y': return '5y';
    case '5y': return '10y';
    default: return '2y';
  }
};

const getCutoffDate = (maxTimestamp, period) => {
  const date = new Date(maxTimestamp);
  switch (period) {
    case '1m': date.setMonth(date.getMonth() - 1); break;
    case '2m': date.setMonth(date.getMonth() - 2); break;
    case '3m': date.setMonth(date.getMonth() - 3); break;
    case '6m': date.setMonth(date.getMonth() - 6); break;
    case '1y': date.setFullYear(date.getFullYear() - 1); break;
    case '2y': date.setFullYear(date.getFullYear() - 2); break;
    case '5y': date.setFullYear(date.getFullYear() - 5); break;
    default: date.setFullYear(date.getFullYear() - 1); break;
  }
  return date.getTime();
};

const AnalysisPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const symbol = searchParams.get('symbol');

  const [activeTab, setActiveTab] = useState('analysis');
  const [selectedPeriod, setSelectedPeriod] = useState('1y');
  const [selectedTimeframe, setSelectedTimeframe] = useState('1d');
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  const [showMA200, setShowMA200] = useState(true);
  const [showBollinger, setShowBollinger] = useState(true);
  const [showSAR, setShowSAR] = useState(true);
  const [showVolumeMA, setShowVolumeMA] = useState(false);
  const [volumeMAPeriod, setVolumeMAPeriod] = useState(20);

  const [chartData, setChartData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [periodAdjustment, setPeriodAdjustment] = useState(null);

  // Strategy state
  const [strategyLoading, setStrategyLoading] = useState(false);
  const [strategyResult, setStrategyResult] = useState(null);
  const [strategyData, setStrategyData] = useState(null);

  const {
    settings,
    appliedSettings,
    updateSetting,
    resetOscillator,
    applySettings,
    validateRange
  } = useOscillatorSettings();

  useEffect(() => {
    if (isPeriodDisabled(selectedPeriod, selectedTimeframe)) {
      const allowedPeriods = periods.filter(p => !isPeriodDisabled(p.value, selectedTimeframe));
      if (allowedPeriods.length > 0) {
        setSelectedPeriod(allowedPeriods[allowedPeriods.length - 1].value);
      }
    }
  }, [selectedTimeframe, selectedPeriod]);

  useEffect(() => {
    if (isFullscreen) document.body.style.overflow = 'hidden';
    else document.body.style.overflow = 'unset';
    return () => { document.body.style.overflow = 'unset'; };
  }, [isFullscreen]);

  useEffect(() => {
    if (!symbol) {
      navigate('/');
      return;
    }
    fetchAnalysisData();
  }, [symbol, selectedPeriod, selectedTimeframe, appliedSettings]);

  const handleApplySettings = () => {
    applySettings();
    toast.success('Oscillator settings applied');
  };

  const fetchAnalysisData = async () => {
    setLoading(true);
    setError(null);
    setPeriodAdjustment(null);

    try {
      const extendedPeriod = getExtendedPeriod(selectedPeriod);
      const queryParams = new URLSearchParams({
        symbol,
        period: extendedPeriod,
        timeframe: selectedTimeframe,
        rsiPeriod: appliedSettings.rsi.period,
        rsiOverbought: appliedSettings.rsi.overbought,
        rsiOversold: appliedSettings.rsi.oversold,
        macdFastEMA: appliedSettings.macd.fastEMA,
        macdSlowEMA: appliedSettings.macd.slowEMA,
        macdSignalLine: appliedSettings.macd.signalLine,
        bbPeriod: appliedSettings.bollingerBands.period,
        bbStdDev: appliedSettings.bollingerBands.stdDev,
        sarAF: appliedSettings.sar.accelerationFactor,
        sarMaxAF: appliedSettings.sar.maxAccelerationFactor,
        ma200Period: appliedSettings.ma200.period,
        ma200Type: appliedSettings.ma200.type
      });

      const url = `/technical-analysis?${queryParams.toString()}`;
      const response = await apiServerClient.fetch(url);

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch analysis data');
      }

      const data = await response.json();
      if (data.periodAdjustment) setPeriodAdjustment(data.periodAdjustment);

      let maxTimestamp = Date.now();
      if (data.candlesticks && data.candlesticks.length > 0) {
        maxTimestamp = Math.max(...data.candlesticks.map(c => new Date(c.timestamp).getTime()));
      }

      const cutoffDate = getCutoffDate(maxTimestamp, selectedPeriod);
      const filterByDate = (arr) => arr ? arr.filter(item => new Date(item.timestamp).getTime() >= cutoffDate) : [];

      setChartData({
        full: data,
        candlesticks: filterByDate(data.candlesticks),
        volumes: filterByDate(data.volumes),
        rsi: filterByDate(data.rsi),
        macd: filterByDate(data.macd),
        ma200: filterByDate(data.ma200),
        bollingerBands: filterByDate(data.bollingerBands),
        sar: filterByDate(data.sar)
      });
    } catch (err) {
      setError(err.message);
      toast.error(err.message || 'Failed to load analysis data');
    } finally {
      setLoading(false);
    }
  };

  const handleExecuteStrategy = async (startDate, endDate, initialCapital, sharesPerTrade) => {
    setStrategyLoading(true);
    try {
      const daysDiff = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 3600 * 24));
      let queryPeriod = '1y';
      if (daysDiff <= 30) queryPeriod = '1m';
      else if (daysDiff <= 90) queryPeriod = '3m';
      else if (daysDiff <= 180) queryPeriod = '6m';
      else if (daysDiff <= 365) queryPeriod = '1y';
      else if (daysDiff <= 730) queryPeriod = '2y';
      else if (daysDiff <= 1825) queryPeriod = '5y';
      else queryPeriod = '10y';

      const queryParams = new URLSearchParams({
        symbol,
        period: queryPeriod,
        timeframe: '1d',
        sarAF: '0.02',
        sarMaxAF: '0.2',
        ma200Period: '200',
        ma200Type: 'SMA'
      });

      const response = await apiServerClient.fetch(`/technical-analysis?${queryParams.toString()}`);
      if (!response.ok) throw new Error('Failed to fetch data for strategy');
      
      const rawData = await response.json();
      
      const filterByRange = (arr) => arr ? arr.filter(item => {
        const time = new Date(item.timestamp).getTime();
        return time >= startDate.getTime() && time <= endDate.getTime();
      }) : [];

      const filteredCandles = filterByRange(rawData.candlesticks);
      const filteredMA = filterByRange(rawData.ma200);
      const filteredSAR = filterByRange(rawData.sar);

      const result = calculateStrategy(filteredCandles, filteredMA, filteredSAR, initialCapital, sharesPerTrade);
      
      setStrategyData({
        candlesticks: filteredCandles,
        ma200: filteredMA,
        sar: filteredSAR
      });
      setStrategyResult(result);
      toast.success('Strategia eseguita con successo');

    } catch (err) {
      toast.error(err.message || 'Errore durante calcolo strategia');
    } finally {
      setStrategyLoading(false);
    }
  };

  const volumeMAData = useMemo(() => {
    if (!showVolumeMA || !chartData?.full?.volumes) return null;
    const vols = chartData.full.volumes;
    const period = volumeMAPeriod || 20;
    const ma = [];
    for (let i = 0; i < vols.length; i++) {
      let sum = 0, count = 0;
      for (let j = i; j >= Math.max(0, i - period + 1); j--) { sum += vols[j].volume || 0; count++; }
      ma.push({ timestamp: vols[i].timestamp, value: count > 0 ? sum / count : 0 });
    }
    return ma;
  }, [chartData?.full?.volumes, showVolumeMA, volumeMAPeriod]);

  const initialPriceForStrategy = chartData?.candlesticks?.[0]?.close || 0;

  if (!symbol) return null;

  const isIntraday = ['5m', '15m', '30m'].includes(selectedTimeframe);
  const isHourly = selectedTimeframe === '1h';

  return (
    <>
      <Helmet>
        <title>{`${symbol} Analysis & Strategy - TechAnalysis Pro`}</title>
      </Helmet>

      <div className="min-h-screen flex flex-col relative pb-32">
        {!isFullscreen && <Header />}

        <main className={isFullscreen ? "p-0 m-0" : "flex-1 py-8 px-4 sm:px-6 lg:px-8"}>
          <div className={isFullscreen ? "w-full h-full" : "max-w-7xl mx-auto"}>
            
            {!isFullscreen && (
              <div className="mb-8">
                <Button variant="ghost" onClick={() => navigate('/')} className="mb-4 transition-all duration-200 active:scale-95">
                  <ArrowLeft className="w-4 h-4 mr-2" /> Back to Search
                </Button>
                <div>
                  <h1 className="text-3xl md:text-4xl font-bold mb-2" style={{ letterSpacing: '-0.02em' }}>{symbol}</h1>
                  <p className="text-muted-foreground">Technical Analysis & Strategy Backtest</p>
                </div>
              </div>
            )}

            {!isFullscreen && (
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="mb-6 h-auto p-1 bg-muted/50 w-full justify-start overflow-x-auto">
                  <TabsTrigger value="analysis" className="px-6 py-2">Analisi Tecnica</TabsTrigger>
                  <TabsTrigger value="strategy" className="px-6 py-2">Backtest Strategia</TabsTrigger>
                </TabsList>

                <TabsContent value="analysis" className="space-y-6 animate-in fade-in duration-500">
                  <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                    <div className="flex flex-col gap-4 w-full">
                      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-end">
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">Period</label>
                          <div className="flex flex-wrap gap-2">
                            {periods.map(period => {
                              const disabled = isPeriodDisabled(period.value, selectedTimeframe);
                              return (
                                <Button key={period.value} variant={selectedPeriod === period.value ? 'default' : 'outline'} size="sm" disabled={disabled} onClick={() => setSelectedPeriod(period.value)} className={disabled ? 'opacity-50 cursor-not-allowed' : 'active:scale-95'}>
                                  {period.label}
                                </Button>
                              );
                            })}
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-muted-foreground">Timeframe</label>
                          <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                            <SelectTrigger className="w-full sm:w-40 bg-background"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {timeframes.map(tf => <SelectItem key={tf.value} value={tf.value}>{tf.label}</SelectItem>)}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>

                      {isIntraday && <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-3 py-2 rounded-md"><Info className="w-4 h-4 shrink-0" /><span>Intraday limit 60 days.</span></div>}
                      {isHourly && <div className="flex items-center gap-2 text-sm text-amber-600 bg-amber-50 px-3 py-2 rounded-md"><Info className="w-4 h-4 shrink-0" /><span>Hourly limit 2 years.</span></div>}
                      {periodAdjustment && !isIntraday && !isHourly && <div className="flex items-center gap-2 text-sm text-blue-600 bg-blue-50 px-3 py-2 rounded-md"><Info className="w-4 h-4 shrink-0" /><span>{periodAdjustment.reason}</span></div>}
                    </div>
                  </div>

                  <OscillatorSettings settings={settings} updateSetting={updateSetting} resetOscillator={resetOscillator} applySettings={handleApplySettings} validateRange={validateRange} />

                  {loading && <div className="flex justify-center py-20 bg-card rounded-xl border border-border mt-8"><Loader2 className="w-10 h-10 animate-spin text-primary" /></div>}
                  {error && !loading && <div className="bg-destructive/10 rounded-xl p-8 text-center mt-8"><p className="text-destructive font-semibold">{error}</p></div>}

                  {!loading && !error && chartData && (
                    <div className="space-y-6 mt-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-card border border-border rounded-xl p-4 shadow-sm">
                        <div className="flex flex-wrap items-center gap-6">
                          <span className="text-sm font-medium text-muted-foreground">Overlays:</span>
                          <div className="flex items-center space-x-2">
                            <Switch id="ma200-toggle" checked={showMA200} onCheckedChange={setShowMA200} />
                            <Label htmlFor="ma200-toggle" className="cursor-pointer font-medium" style={{ color: 'hsl(var(--ma200))' }}>MA ({appliedSettings.ma200.period} {appliedSettings.ma200.type})</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch id="bollinger-toggle" checked={showBollinger} onCheckedChange={setShowBollinger} />
                            <Label htmlFor="bollinger-toggle" className="cursor-pointer font-medium" style={{ color: 'hsl(var(--osc-bb))' }}>Bollinger ({appliedSettings.bollingerBands.period}, {appliedSettings.bollingerBands.stdDev})</Label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Switch id="sar-toggle" checked={showSAR} onCheckedChange={setShowSAR} />
                            <Label htmlFor="sar-toggle" className="cursor-pointer font-medium" style={{ color: 'hsl(var(--osc-sar))' }}>SAR ({appliedSettings.sar.accelerationFactor}, {appliedSettings.sar.maxAccelerationFactor})</Label>
                          </div>
                        </div>
                      </div>

                      <div className="bg-card border border-border rounded-xl p-4 shadow-sm relative">
                        <div className="absolute top-6 right-6 z-10"><Button variant="secondary" size="icon" onClick={() => setIsFullscreen(!isFullscreen)}><Maximize2 className="w-4 h-4" /></Button></div>
                        <CandlestickChart
                          data={chartData.full.candlesticks} volumes={chartData.full.volumes} ma200={chartData.full.ma200}
                          bollingerBands={chartData.full.bollingerBands} sar={chartData.full.sar} volumeMA={volumeMAData}
                          rsi={chartData.full.rsi} macd={chartData.full.macd} symbol={symbol} selectedPeriod={selectedPeriod}
                          showMA200={showMA200} showBollinger={showBollinger} showSAR={showSAR} showVolumeMA={showVolumeMA}
                          setShowVolumeMA={setShowVolumeMA} volumeMAPeriod={volumeMAPeriod} setVolumeMAPeriod={setVolumeMAPeriod}
                          sarAF={appliedSettings.sar.accelerationFactor} sarMaxAF={appliedSettings.sar.maxAccelerationFactor}
                          ma200Period={appliedSettings.ma200.period} ma200Type={appliedSettings.ma200.type} isFullscreen={false}
                        />
                      </div>

                      <div className="bg-card border border-border rounded-xl p-4 shadow-sm relative">
                        <div className="absolute top-4 left-6 z-10 text-xs font-semibold px-2 py-1 rounded bg-background/80 border border-border" style={{ color: 'hsl(var(--osc-rsi))' }}>RSI ({appliedSettings.rsi.period})</div>
                        <RSIChart data={chartData.rsi} />
                      </div>

                      <div className="bg-card border border-border rounded-xl p-4 shadow-sm relative">
                        <div className="absolute top-4 left-6 z-10 text-xs font-semibold px-2 py-1 rounded bg-background/80 border border-border" style={{ color: 'hsl(var(--osc-macd))' }}>MACD ({appliedSettings.macd.fastEMA}, {appliedSettings.macd.slowEMA}, {appliedSettings.macd.signalLine})</div>
                        <MACDChart data={chartData.macd} />
                      </div>

                      {/* SAR Debug Section */}
                      {chartData.full.sar && chartData.full.sar.length > 0 && (
                        <Card className="border-border shadow-sm bg-muted/10">
                          <CardHeader className="pb-3">
                            <CardTitle className="text-lg flex items-center gap-2">
                              <Activity className="w-5 h-5 text-primary" />
                              SAR Debug Information
                            </CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div className="space-y-4">
                                <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Current Status (Last Candle)</h4>
                                {(() => {
                                  const lastSar = chartData.full.sar[chartData.full.sar.length - 1];
                                  return (
                                    <div className="grid grid-cols-2 gap-4 bg-background p-4 rounded-lg border border-border">
                                      <div>
                                        <span className="block text-xs text-muted-foreground mb-1">Value</span>
                                        <span className="font-medium">{lastSar.value.toFixed(2)}</span>
                                      </div>
                                      <div>
                                        <span className="block text-xs text-muted-foreground mb-1">Trend</span>
                                        <Badge variant={lastSar.trend === 'uptrend' ? 'default' : 'destructive'} className="capitalize">
                                          {lastSar.trend}
                                        </Badge>
                                      </div>
                                      <div>
                                        <span className="block text-xs text-muted-foreground mb-1">Acceleration Factor (AF)</span>
                                        <span className="font-medium">{lastSar.af.toFixed(4)}</span>
                                      </div>
                                      <div>
                                        <span className="block text-xs text-muted-foreground mb-1">Extreme Point (EP)</span>
                                        <span className="font-medium">{lastSar.ep.toFixed(2)}</span>
                                      </div>
                                    </div>
                                  );
                                })()}
                              </div>
                              <div className="space-y-4">
                                <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Last 5 SAR Values</h4>
                                <div className="bg-background rounded-lg border border-border overflow-hidden">
                                  <table className="w-full text-sm text-left">
                                    <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                                      <tr>
                                        <th className="px-4 py-2 font-medium">Date</th>
                                        <th className="px-4 py-2 font-medium">Value</th>
                                        <th className="px-4 py-2 font-medium">Trend</th>
                                      </tr>
                                    </thead>
                                    <tbody className="divide-y divide-border">
                                      {chartData.full.sar.slice(-5).reverse().map((s, i) => (
                                        <tr key={i} className="hover:bg-muted/20">
                                          <td className="px-4 py-2">{new Date(s.timestamp).toLocaleDateString()}</td>
                                          <td className="px-4 py-2 font-medium">{s.value.toFixed(2)}</td>
                                          <td className="px-4 py-2">
                                            <span className={s.trend === 'uptrend' ? 'text-green-600' : 'text-red-600'}>
                                              {s.trend}
                                            </span>
                                          </td>
                                        </tr>
                                      ))}
                                    </tbody>
                                  </table>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="strategy" className="space-y-6 animate-in fade-in duration-500">
                  <StrategyExecutor 
                    onExecute={handleExecuteStrategy} 
                    loading={strategyLoading} 
                    initialPrice={initialPriceForStrategy}
                    candlesticks={chartData?.full?.candlesticks}
                    symbol={symbol}
                  />
                  
                  {strategyData && strategyResult && (
                    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500">
                      <StrategyStats stats={strategyResult.stats} />
                      
                      <StrategyChart 
                        data={strategyData.candlesticks}
                        ma200={strategyData.ma200}
                        sar={strategyData.sar}
                        trades={strategyResult.trades}
                        equityLine={strategyResult.equityLine}
                        initialCapital={strategyResult.stats.initialCapital}
                        symbol={symbol}
                      />

                      <TradesTable trades={strategyResult.trades} />
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            )}
            
            {isFullscreen && chartData && (
              <div className="w-full h-full p-0">
                <div className="fixed top-6 right-6 z-[60]"><Button variant="secondary" size="icon" onClick={() => setIsFullscreen(false)}><Minimize2 className="w-4 h-4" /></Button></div>
                <CandlestickChart
                  data={chartData.full.candlesticks} volumes={chartData.full.volumes} ma200={chartData.full.ma200}
                  bollingerBands={chartData.full.bollingerBands} sar={chartData.full.sar} volumeMA={volumeMAData}
                  rsi={chartData.full.rsi} macd={chartData.full.macd} symbol={symbol} selectedPeriod={selectedPeriod}
                  showMA200={showMA200} showBollinger={showBollinger} showSAR={showSAR} showVolumeMA={showVolumeMA}
                  setShowVolumeMA={setShowVolumeMA} volumeMAPeriod={volumeMAPeriod} setVolumeMAPeriod={setVolumeMAPeriod}
                  sarAF={appliedSettings.sar.accelerationFactor} sarMaxAF={appliedSettings.sar.maxAccelerationFactor}
                  ma200Period={appliedSettings.ma200.period} ma200Type={appliedSettings.ma200.type} isFullscreen={true}
                />
              </div>
            )}
          </div>
        </main>

        {!isFullscreen && <Footer />}
        {!isFullscreen && <DebugPanel />}
      </div>
    </>
  );
};

export default AnalysisPage;
