# Testing Guide - Parabolic SAR & Historical Data Fixes

## Quick Start

### 1. Start the API Server
```bash
cd apps/api
npm run dev
```

**Expected Output**:
```
🚀 API Server running on http://localhost:3001
```

### 2. Test Historical Data Accuracy

#### Test GOOGL with 2-year history
```bash
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=2y&timeframe=1d"
```

**Check the logs for**:
```
[YAHOO-FETCH] Currency: USD
[YAHOO-FETCH] Exchange: NASDAQ
[YAHOO-FETCH] Total timestamps: 252
[YAHOO-FETCH] First candle: 2024-01-01T... - O:140.5 H:142.3 L:139.8 C:141.2
[YAHOO-FETCH] Last candle: 2025-01-01T... - O:300.2 H:302.5 L:299.8 C:301.5
```

**Validate in Response**:
- Last candle close should be ~$300 USD (current GOOGL price)
- First candle close should be ~$140 USD (2 years ago)
- All prices should be in USD, NOT euros
- No currency conversion errors

#### Test GOOGL with 4-year history (includes stock split)
```bash
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=5y&timeframe=1d"
```

**Validate**:
- April 2022 prices should be ~$110-115 USD (pre-split)
- July 2022 should show the 20-for-1 stock split adjustment
- All prices should be consistent (no currency conversion)
- Stock split is automatically handled by Yahoo Finance

---

## 3. Test SAR Calculation

### Test SAR Array Length
```bash
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d" | jq '.candlesticks | length'
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d" | jq '.sar | length'
```

**Expected**: Both should return the same number (e.g., 252)

### Test SAR Values Are Reasonable
```bash
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d" | jq '.sar[0:5]'
```

**Expected Output**:
```json
[
  { "timestamp": 1704067200000, "value": 140.5 },
  { "timestamp": 1704153600000, "value": 140.45 },
  { "timestamp": 1704240000000, "value": 140.40 },
  { "timestamp": 1704326400000, "value": 140.35 },
  { "timestamp": 1704412800000, "value": 140.30 }
]
```

**Validate**:
- SAR values are numbers (not NaN, not Infinity)
- SAR values are within price range (between low and high)
- SAR values change gradually (not jumping)
- SAR values are 2 decimal places

### Test SAR Continuous Tracking (No Daily Reset)
```bash
curl "http://localhost:3001/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d" | jq '.sar | map(.value) | .[0:20]'
```

**Expected**: SAR values should form a continuous trend line, not reset at any point

**NOT Expected**: SAR should NOT jump to a completely different value (unless trend reversal)

---

## 4. Test with Frontend Backtest

### Run Backtest with SAR Strategy

1. Open the frontend application
2. Navigate to the backtest section
3. Select GOOGL ticker
4. Select SAR strategy
5. Set period to 1 year
6. Run backtest

### Check Trade Durations

**Expected Results**:
- Most trades should last >1 day
- Some trades may last 1 day if SAR crosses immediately
- NO trades should last only a few hours (unless SAR crosses immediately)

**Log Output** (add to StrategyCalculator.js):
```javascript
// Log first 5 trades
if (tradeCount <= 5) {
  console.log(`Trade ${tradeCount}:`);
  console.log(`  Entry: ${entryDate} at $${entryPrice}`);
  console.log(`  Exit: ${exitDate} at $${exitPrice}`);
  console.log(`  SAR at exit: $${sarAtExit}`);
  console.log(`  Duration: ${(exitDate - entryDate) / (1000 * 60 * 60 * 24)} days`);
}
```

### Validate Exit Conditions

**For Uptrend Trades**:
- Exit should occur when: `price < SAR`
- SAR value at exit should be above the exit price

**For Downtrend Trades**:
- Exit should occur when: `price > SAR`
- SAR value at exit should be below the exit price

---

## 5. Debug Logging

### Enable Detailed Logging

Add this to your backtest code to log SAR values:

```javascript
// In StrategyCalculator.js, add to the main loop:
if (i < 5 || i % 50 === 0) {
  logger.info(`[BACKTEST] Candle ${i}: Date=${new Date(dates[i]).toISOString()}, Price=${prices[i]}, SAR=${sar[i].value}, Trend=${isUptrend ? 'UP' : 'DOWN'}`);
}
```

### Check for Common Issues

#### Issue 1: All Trades Last 1 Day
**Debug**:
```javascript
const tradeDurations = trades.map(t => (t.exitDate - t.entryDate) / (1000 * 60 * 60 * 24));
console.log('Trade durations (days):', tradeDurations);
console.log('Average duration:', tradeDurations.reduce((a, b) => a + b) / tradeDurations.length);
```

**If all are 1 day**:
- Check if SAR is resetting at end of day
- Verify SAR calculation is continuous
- Check if exit condition is checking end-of-day instead of SAR crossing

#### Issue 2: SAR Values Are Wrong
**Debug**:
```javascript
// Compare with TradingView
// 1. Get SAR values from API
// 2. Get SAR values from TradingView
// 3. Compare first 10 values
const apiSAR = response.sar.slice(0, 10).map(s => s.value);
console.log('API SAR:', apiSAR);
// Manually check TradingView SAR values
```

#### Issue 3: Currency Conversion
**Debug**:
```javascript
// Check API response
const response = await fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d');
const data = await response.json();
console.log('Last candle close:', data.candlesticks[data.candlesticks.length - 1].close);
// Should be ~$300, NOT €252
```

---

## 6. Automated Test Cases

### Test 1: Historical Data Accuracy
```javascript
async function testHistoricalData() {
  const response = await fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=2y&timeframe=1d');
  const data = await response.json();
  
  // Check last candle is recent
  const lastCandle = data.candlesticks[data.candlesticks.length - 1];
  const lastDate = new Date(lastCandle.timestamp);
  const today = new Date();
  const daysDiff = (today - lastDate) / (1000 * 60 * 60 * 24);
  
  console.assert(daysDiff < 7, `Last candle is ${daysDiff} days old, should be < 7`);
  console.assert(lastCandle.close > 250, `GOOGL price is $${lastCandle.close}, should be > $250`);
  console.assert(lastCandle.close < 350, `GOOGL price is $${lastCandle.close}, should be < $350`);
  
  console.log('✓ Historical data accuracy test passed');
}
```

### Test 2: SAR Array Length
```javascript
async function testSARArrayLength() {
  const response = await fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d');
  const data = await response.json();
  
  const candleCount = data.candlesticks.length;
  const sarCount = data.sar.length;
  
  console.assert(candleCount === sarCount, `SAR count (${sarCount}) != candle count (${candleCount})`);
  console.log(`✓ SAR array length test passed (${sarCount} values)`);
}
```

### Test 3: SAR Values Are Reasonable
```javascript
async function testSARValues() {
  const response = await fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d');
  const data = await response.json();
  
  for (let i = 0; i < data.sar.length; i++) {
    const sar = data.sar[i];
    const candle = data.candlesticks[i];
    
    console.assert(!isNaN(sar.value), `SAR value is NaN at index ${i}`);
    console.assert(isFinite(sar.value), `SAR value is Infinity at index ${i}`);
    console.assert(sar.value > 0, `SAR value is ${sar.value} at index ${i}, should be > 0`);
    
    // SAR should be within a reasonable range of the price
    const priceDiff = Math.abs(sar.value - candle.close) / candle.close;
    console.assert(priceDiff < 0.5, `SAR is ${priceDiff * 100}% away from price at index ${i}`);
  }
  
  console.log('✓ SAR values test passed');
}
```

### Test 4: Trade Duration
```javascript
async function testTradeDuration() {
  // Run backtest
  const trades = await runBacktest('GOOGL', 'SAR', '1y');
  
  const durations = trades.map(t => (t.exitDate - t.entryDate) / (1000 * 60 * 60 * 24));
  const avgDuration = durations.reduce((a, b) => a + b) / durations.length;
  
  console.assert(avgDuration > 1, `Average trade duration is ${avgDuration} days, should be > 1`);
  console.assert(durations.filter(d => d > 1).length > durations.length * 0.5, `Less than 50% of trades last > 1 day`);
  
  console.log(`✓ Trade duration test passed (avg: ${avgDuration.toFixed(2)} days)`);
}
```

---

## 7. Manual Verification Steps

### Step 1: Verify Currency
1. Open browser console
2. Run:
   ```javascript
   fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d')
     .then(r => r.json())
     .then(d => console.log('Last price:', d.candlesticks[d.candlesticks.length - 1].close))
   ```
3. Check if price is ~$300 (USD) or ~€252 (EUR)
4. If EUR, check logs for which symbol variant was used

### Step 2: Verify SAR Continuity
1. Get SAR values:
   ```javascript
   fetch('/hcgi/api/technical-analysis?symbol=GOOGL&period=1y&timeframe=1d')
     .then(r => r.json())
     .then(d => console.log(d.sar.slice(0, 20).map(s => s.value)))
   ```
2. Check if values form a continuous trend (no sudden jumps)
3. Check if values change gradually (not resetting)

### Step 3: Verify Trade Exits
1. Run backtest
2. For first 5 trades, log:
   - Entry date and price
   - Exit date and price
   - SAR value at exit
   - Verify: price < SAR (uptrend) or price > SAR (downtrend)

---

## 8. Expected Results Summary

### Historical Data
- ✅ GOOGL March 2026: ~$300 USD
- ✅ GOOGL April 2022: ~$110-115 USD (pre-split)
- ✅ Currency: USD (not EUR)
- ✅ Exchange: NASDAQ

### SAR Calculation
- ✅ SAR array length = candlesticks array length
- ✅ SAR values are continuous (no daily resets)
- ✅ SAR values change gradually
- ✅ SAR values are within price range

### Backtest Results
- ✅ Average trade duration > 1 day
- ✅ Exit conditions based on SAR crossing (not end of day)
- ✅ Exit condition: price < SAR (uptrend) or price > SAR (downtrend)
- ✅ No currency conversion errors

---

## 9. Troubleshooting Checklist

- [ ] API server is running on port 3001
- [ ] Historical data shows USD prices (not EUR)
- [ ] SAR array length matches candlesticks array length
- [ ] SAR values are continuous (no daily resets)
- [ ] Trade durations are > 1 day (on average)
- [ ] Exit conditions are based on SAR crossing
- [ ] Logs show correct currency and exchange
- [ ] No NaN or Infinity values in SAR array
- [ ] Stock split is handled correctly (GOOGL July 2022)
- [ ] First 5 trades have correct exit conditions
