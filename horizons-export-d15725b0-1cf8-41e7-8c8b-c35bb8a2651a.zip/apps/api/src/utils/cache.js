/**
 * In-memory cache with TTL support
 */
const cache = new Map();

/**
 * Get value from cache if not expired
 */
export function getFromCache(key) {
  const item = cache.get(key);
  if (!item) return null;

  if (Date.now() > item.expiresAt) {
    cache.delete(key);
    return null;
  }

  return item.value;
}

/**
 * Set value in cache with TTL (in seconds)
 */
export function setInCache(key, value, ttlSeconds) {
  const expiresAt = Date.now() + ttlSeconds * 1000;
  cache.set(key, { value, expiresAt });
}

/**
 * Clear all cache
 */
export function clearCache() {
  cache.clear();
}

/**
 * Clear expired cache entries
 */
export function clearExpiredCache() {
  const now = Date.now();
  for (const [key, item] of cache.entries()) {
    if (now > item.expiresAt) {
      cache.delete(key);
    }
  }
}
