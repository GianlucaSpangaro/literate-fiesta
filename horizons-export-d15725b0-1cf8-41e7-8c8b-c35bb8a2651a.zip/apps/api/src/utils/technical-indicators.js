/**
 * Calculate Simple Moving Average (SMA)
 */
export function calculateSMA(data, period) {
  const result = [];
  for (let i = period - 1; i < data.length; i++) {
    const slice = data.slice(i - period + 1, i + 1);
    const closes = slice.map(c => c.close);
    const sma = closes.reduce((a, b) => a + b, 0) / period;
    result.push({
      timestamp: data[i].timestamp,
      value: parseFloat(sma.toFixed(2)),
    });
  }
  return result;
}

/**
 * Calculate Bollinger Bands
 */
export function calculateBollingerBands(data, period, stdDev) {
  const result = [];
  for (let i = period - 1; i < data.length; i++) {
    const slice = data.slice(i - period + 1, i + 1);
    const closes = slice.map(c => c.close);
    const mean = closes.reduce((a, b) => a + b, 0) / period;
    const variance = closes.reduce((a, c) => a + Math.pow(c - mean, 2), 0) / period;
    const std = Math.sqrt(variance);
    result.push({
      timestamp: data[i].timestamp,
      upper: parseFloat((mean + stdDev * std).toFixed(2)),
      middle: parseFloat(mean.toFixed(2)),
      lower: parseFloat((mean - stdDev * std).toFixed(2)),
    });
  }
  return result;
}

/**
 * Calculate Relative Strength Index (RSI)
 */
export function calculateRSI(data, period) {
  const result = [];
  const changes = [];

  for (let i = 1; i < data.length; i++) {
    changes.push(data[i].close - data[i - 1].close);
  }

  let avgGain = 0;
  let avgLoss = 0;

  for (let i = 0; i < period; i++) {
    const change = changes[i];
    if (change > 0) avgGain += change;
    else avgLoss += Math.abs(change);
  }

  avgGain /= period;
  avgLoss /= period;

  for (let i = period; i < changes.length; i++) {
    const change = changes[i];
    const gain = change > 0 ? change : 0;
    const loss = change < 0 ? Math.abs(change) : 0;

    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;

    const rs = avgLoss === 0 ? 100 : avgGain / avgLoss;
    const rsi = 100 - 100 / (1 + rs);

    result.push({
      timestamp: data[i + 1].timestamp,
      value: parseFloat(rsi.toFixed(2)),
    });
  }

  return result;
}

/**
 * Calculate MACD (Moving Average Convergence Divergence)
 */
export function calculateMACD(data, fastPeriod, slowPeriod, signalPeriod) {
  const result = [];

  // Controllo di sicurezza: se i dati non bastano per il calcolo, esce subito senza crashare
  if (!data || data.length < slowPeriod) {
    return result;
  }

  const emaFast = calculateEMA(data, fastPeriod);
  const emaSlow = calculateEMA(data, slowPeriod);

  const macdLine = [];
  for (let i = 0; i < Math.min(emaFast.length, emaSlow.length); i++) {
    macdLine.push(emaFast[i] - emaSlow[i]);
  }

  const signalLine = calculateEMAFromArray(macdLine, signalPeriod);

  // Calcoliamo lo sfasamento (offset) esatto tra l'array dei dati iniziali (data)
  // e la macdLine, per essere certi di prendere sempre il timestamp corretto
  const offset = data.length - macdLine.length;

  for (let i = 0; i < macdLine.length; i++) {
    const signalIndex = i - (macdLine.length - signalLine.length);

    // Generiamo l'istogramma e il punto finale solo se la linea del segnale è pronta
    if (signalIndex >= 0 && signalLine[signalIndex] !== undefined) {
      const histogram = macdLine[i] - signalLine[signalIndex];

      // Indice sicuro per il timestamp: non andrà MAI oltre la lunghezza di data
      const dataIndex = offset + i;

      if (data[dataIndex]) {
        result.push({
          timestamp: data[dataIndex].timestamp,
          macd: parseFloat(macdLine[i].toFixed(2)),
          signal: parseFloat(signalLine[signalIndex].toFixed(2)),
          histogram: parseFloat(histogram.toFixed(2)),
        });
      }
    }
  }

  return result;
}

/**
 * Calculate Exponential Moving Average (EMA)
 */
function calculateEMA(data, period) {
  const result = [];
  const multiplier = 2 / (period + 1);
  let ema = null;

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      continue;
    }

    if (ema === null) {
      // First EMA is SMA
      const slice = data.slice(0, period);
      ema = slice.reduce((sum, candle) => sum + candle.close, 0) / period;
    } else {
      ema = (data[i].close - ema) * multiplier + ema;
    }

    result.push(ema);
  }

  return result;
}

/**
 * Calculate EMA from an array of values
 */
function calculateEMAFromArray(values, period) {
  const result = [];
  const multiplier = 2 / (period + 1);
  let ema = null;

  for (let i = 0; i < values.length; i++) {
    if (i < period - 1) {
      continue;
    }

    if (ema === null) {
      ema = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
    } else {
      ema = (values[i] - ema) * multiplier + ema;
    }

    result.push(ema);
  }

  return result;
}

/**
 * Calculate Parabolic SAR (Stop and Reverse)
 * 
 * CRITICAL IMPLEMENTATION NOTES:
 * ================================
 * 
 * SAR is a trailing stop that follows price in the direction of the trend.
 * It does NOT reset at end of day - it only exits when price crosses SAR.
 * 
 * INITIALIZATION:
 * - SAR starts at the low of the first candle (assuming uptrend)
 * - Extreme Point (EP): Highest high in uptrend, lowest low in downtrend
 * - Acceleration Factor (AF): Starts at 0.02, increments by 0.02 when new extreme reached, capped at 0.2
 * 
 * SAR CALCULATION:
 * - Uptrend: SAR(t) = SAR(t-1) + AF * (HP - SAR(t-1)) where HP = highest point
 * - Downtrend: SAR(t) = SAR(t-1) - AF * (SAR(t-1) - LP) where LP = lowest point
 * 
 * SAR CONSTRAINTS (SAR Smoothing):
 * - Uptrend: SAR cannot be above the last 2 candles' lows
 *   Formula: SAR = Math.min(SAR, prevCandle.low, prev2Candle.low)
 * - Downtrend: SAR cannot be below the last 2 candles' highs
 *   Formula: SAR = Math.max(SAR, prevCandle.high, prev2Candle.high)
 * 
 * TREND REVERSAL:
 * - Uptrend Exit: When candle.close < SAR
 *   Action: SAR = HP (becomes previous high), LP = candle.low, AF = 0.02
 * - Downtrend Exit: When candle.close > SAR
 *   Action: SAR = LP (becomes previous low), HP = candle.high, AF = 0.02
 * 
 * RETURN FORMAT:
 * - Array length matches input data length (one SAR value per candle)
 * - Each entry: { timestamp, value, trend, af, ep }
 * - value: SAR price at that candle (2 decimal places)
 * - trend: 'uptrend' or 'downtrend'
 * - af: Current acceleration factor
 * - ep: Current extreme point
 * 
 * @param {Array} data - Array of OHLCV candles
 * @param {number} initialAF - Initial acceleration factor (default 0.02)
 * @param {number} maxAF - Maximum acceleration factor (default 0.2)
 * @returns {Array} - Array of SAR values with metadata for every candle
 */
export function calculateSAR(data, initialAF = 0.02, maxAF = 0.2) {
  const result = [];
  
  if (!data || data.length < 2) {
    return result;
  }

  // STEP 1: INITIALIZATION
  // Assume we start in an uptrend
  let isUptrend = true;
  let sar = data[0].low;        // SAR starts at the low of the first candle
  let af = initialAF;           // Acceleration factor starts at 0.02
  let hp = data[0].high;        // Highest point in current trend
  let lp = data[0].low;         // Lowest point in current trend

  // Add SAR for first candle (SAR is initialized but not yet calculated)
  result.push({
    timestamp: data[0].timestamp,
    value: parseFloat(sar.toFixed(2)),
    trend: 'uptrend',
    af: parseFloat(af.toFixed(4)),
    ep: parseFloat(hp.toFixed(2)),
  });

  // STEP 2: PROCESS EACH CANDLE STARTING FROM THE SECOND ONE
  for (let i = 1; i < data.length; i++) {
    const candle = data[i];
    const prevCandle = data[i - 1];
    const prev2Candle = i > 1 ? data[i - 2] : null;

    if (isUptrend) {
      // UPTREND: SAR is below price, we're looking for a reversal (price closes below SAR)
      
      // STEP 2.1: Calculate new SAR
      // Formula: SAR(t) = SAR(t-1) + AF * (HP - SAR(t-1))
      sar = sar + af * (hp - sar);
      
      // STEP 2.2: Apply SAR constraints (SAR smoothing)
      // In uptrend, SAR cannot be above the last 2 candles' lows
      sar = Math.min(sar, prevCandle.low);
      if (prev2Candle) {
        sar = Math.min(sar, prev2Candle.low);
      }

      // STEP 2.3: Check if we hit a new high (update extreme point and AF)
      if (candle.high > hp) {
        hp = candle.high;
        // Increment AF by initialAF, but cap at maxAF
        af = Math.min(af + initialAF, maxAF);
      }

      // STEP 2.4: Check for trend reversal
      // Exit condition: price closes below SAR
      if (candle.close < sar) {
        // REVERSAL: Switch to downtrend
        isUptrend = false;
        sar = hp;           // SAR becomes the previous high
        lp = candle.low;    // New low point
        af = initialAF;     // Reset AF to initial value
      }
    } else {
      // DOWNTREND: SAR is above price, we're looking for a reversal (price closes above SAR)
      
      // STEP 2.1: Calculate new SAR
      // Formula: SAR(t) = SAR(t-1) - AF * (SAR(t-1) - LP)
      sar = sar - af * (sar - lp);
      
      // STEP 2.2: Apply SAR constraints (SAR smoothing)
      // In downtrend, SAR cannot be below the last 2 candles' highs
      sar = Math.max(sar, prevCandle.high);
      if (prev2Candle) {
        sar = Math.max(sar, prev2Candle.high);
      }

      // STEP 2.3: Check if we hit a new low (update extreme point and AF)
      if (candle.low < lp) {
        lp = candle.low;
        // Increment AF by initialAF, but cap at maxAF
        af = Math.min(af + initialAF, maxAF);
      }

      // STEP 2.4: Check for trend reversal
      // Exit condition: price closes above SAR
      if (candle.close > sar) {
        // REVERSAL: Switch to uptrend
        isUptrend = true;
        sar = lp;           // SAR becomes the previous low
        hp = candle.high;   // New high point
        af = initialAF;     // Reset AF to initial value
      }
    }

    // STEP 3: Add SAR value for this candle
    result.push({
      timestamp: candle.timestamp,
      value: parseFloat(sar.toFixed(2)),
      trend: isUptrend ? 'uptrend' : 'downtrend',
      af: parseFloat(af.toFixed(4)),
      ep: isUptrend ? parseFloat(hp.toFixed(2)) : parseFloat(lp.toFixed(2)),
    });
  }

  return result;
}

/**
 * Calculate Stochastic Oscillator
 * @param {Array} data - Array of OHLCV candles
 * @param {number} kPeriod - K period (lookback period for high/low)
 * @param {number} dPeriod - D period (SMA period for %K)
 * @returns {Array} - Array of stochastic values with %K and %D
 */
export function calculateStochastic(data, kPeriod = 14, dPeriod = 3) {
  const result = [];

  if (!data || data.length < kPeriod) {
    return result;
  }

  const kValues = [];

  // Calculate %K for each candle
  for (let i = kPeriod - 1; i < data.length; i++) {
    const slice = data.slice(i - kPeriod + 1, i + 1);
    const highs = slice.map(c => c.high);
    const lows = slice.map(c => c.low);

    const highest = Math.max(...highs);
    const lowest = Math.min(...lows);
    const close = data[i].close;

    const k = highest === lowest ? 50 : ((close - lowest) / (highest - lowest)) * 100;
    kValues.push(k);
  }

  // Calculate %D (SMA of %K)
  const dValues = [];
  for (let i = dPeriod - 1; i < kValues.length; i++) {
    const slice = kValues.slice(i - dPeriod + 1, i + 1);
    const d = slice.reduce((a, b) => a + b, 0) / dPeriod;
    dValues.push(d);
  }

  // Build result array with both %K and %D
  const offset = data.length - kValues.length;
  for (let i = 0; i < kValues.length; i++) {
    const dIndex = i - (kValues.length - dValues.length);
    const dataIndex = offset + i;

    if (data[dataIndex]) {
      result.push({
        timestamp: data[dataIndex].timestamp,
        k: parseFloat(kValues[i].toFixed(2)),
        d: dIndex >= 0 && dValues[dIndex] !== undefined ? parseFloat(dValues[dIndex].toFixed(2)) : null,
      });
    }
  }

  return result;
}
