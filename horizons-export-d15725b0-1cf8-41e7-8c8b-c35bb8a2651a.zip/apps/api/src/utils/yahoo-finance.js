import 'dotenv/config';
import logger from './logger.js';

/**
 * Convert period string to seconds
 * @param {string} period - Period string (e.g., '1m', '1y')
 * @returns {number} - Number of seconds
 */
function getPeriodSeconds(period) {
  const periodMap = {
    '1m': 30 * 24 * 60 * 60,       // 30 days
    '2m': 60 * 24 * 60 * 60,       // 60 days
    '3m': 90 * 24 * 60 * 60,       // 90 days
    '6m': 180 * 24 * 60 * 60,      // 180 days
    '1y': 365 * 24 * 60 * 60,      // 365 days
    '2y': 2 * 365 * 24 * 60 * 60,  // 2 years
    '5y': 5 * 365 * 24 * 60 * 60,  // 5 years
    '10y': 10 * 365 * 24 * 60 * 60, // 10 years
  };
  return periodMap[period] || 365 * 24 * 60 * 60;
}

/**
 * Generate symbol variants to try in order
 * Variants: (1) original, (2) without market suffix, (3) with .MI, (4) with .L
 * @param {string} symbol - Original symbol (e.g., 'STLA.MI', 'AMZN')
 * @returns {Array<string>} - Array of symbol variants to try
 */
export function getSymbolVariants(symbol) {
  const variants = [];
  const symbolUpper = symbol.toUpperCase().trim();
  
  // (1) Original symbol - ALWAYS try first
  variants.push(symbolUpper);
  
  // (2) Symbol without market suffix (.MI, .L, .DE, etc.) - only if original has a suffix
  const baseSymbol = symbolUpper.split('.')[0];
  if (baseSymbol !== symbolUpper) {
    variants.push(baseSymbol);
  }
  
  // (3) Symbol with .MI suffix if not already present and not already tried
  if (!symbolUpper.endsWith('.MI') && baseSymbol !== symbolUpper) {
    variants.push(`${baseSymbol}.MI`);
  }
  
  // (4) Symbol with .L suffix if not already present and not already tried
  if (!symbolUpper.endsWith('.L') && baseSymbol !== symbolUpper) {
    variants.push(`${baseSymbol}.L`);
  }
  
  // Remove duplicates while preserving order
  return [...new Set(variants)];
}

/**
 * Fetch historical OHLCV data from Yahoo Finance API (JSON v8) with intelligent fallback
 * Downloads ALL available data for the specified period without truncation
 * @param {string} symbol - Stock symbol (e.g., 'AAPL', 'STLA.MI')
 * @param {string} period - Time period (e.g., '1y', '6m', '2m')
 * @param {string} interval - Candle interval (e.g., '1d', '1h', '15m', '5m')
 * @returns {Promise<Array>} - Array of OHLCV candles with adjusted close
 */
export async function fetchYahooFinanceData(symbol, period, interval = '1d') {
  const originalSymbol = symbol.toUpperCase().trim();
  const variants = getSymbolVariants(originalSymbol);
  
  logger.info(`[YAHOO-FINANCE] Fetching data for symbol: ${originalSymbol}`);
  logger.info(`[YAHOO-FINANCE] Generated ${variants.length} variants to try: ${variants.join(', ')}`);
  
  let lastError = null;
  
  // Try each variant in sequence
  for (let i = 0; i < variants.length; i++) {
    const currentSymbol = variants[i];
    const nextVariant = i < variants.length - 1 ? variants[i + 1] : null;
    
    try {
      logger.info(`[YAHOO-FINANCE] Trying symbol: ${currentSymbol}`);
      
      const data = await fetchYahooFinanceDataInternal(currentSymbol, period, interval);
      
      logger.info(`[YAHOO-FINANCE] Success with symbol: ${currentSymbol}`);
      return data;
    } catch (error) {
      lastError = error;
      
      // Check if it's a 404 error
      if (error.message.includes('404')) {
        if (nextVariant) {
          logger.info(`[YAHOO-FINANCE] Symbol ${currentSymbol} failed with 404, trying ${nextVariant}`);
        } else {
          logger.warn(`[YAHOO-FINANCE] Symbol ${currentSymbol} failed with 404, no more variants to try`);
        }
      } else {
        // For non-404 errors, throw immediately
        throw error;
      }
    }
  }
  
  // All variants failed
  const variantsList = variants.join(', ');
  const errorMessage = `Symbol ${originalSymbol} not found in Yahoo Finance (tried: ${variantsList})`;
  logger.error(`[YAHOO-FINANCE] ${errorMessage}`);
  throw new Error(errorMessage);
}

/**
 * Fetch EURUSD exchange rate history for a specific date range
 * Downloads ALL available daily rates for the specified period
 * @param {number} startTime - Unix timestamp (seconds) for start of range
 * @param {number} endTime - Unix timestamp (seconds) for end of range
 * @returns {Promise<Object>} - Map of date (YYYY-MM-DD) to EURUSD rate
 */
export async function fetchEURUSDRates(startTime, endTime) {
  logger.info(`[EURUSD-FETCH] Fetching EURUSD rates from ${new Date(startTime * 1000).toISOString()} to ${new Date(endTime * 1000).toISOString()}`);

  const url = `https://query1.finance.yahoo.com/v8/finance/chart/EURUSD=X?period1=${startTime}&period2=${endTime}&interval=1d`;

  logger.info(`[EURUSD-FETCH] Requesting URL: ${url}`);

  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Origin': 'https://finance.yahoo.com',
      'Referer': 'https://finance.yahoo.com/'
    },
  });

  logger.info(`[EURUSD-FETCH] Response status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    logger.error(`[EURUSD-FETCH] API error: ${response.status} ${response.statusText}`);
    throw new Error(`Yahoo Finance API error for EURUSD: ${response.status} ${response.statusText}`);
  }

  const json = await response.json();
  const result = json.chart?.result?.[0];
  
  if (!result || !result.timestamp) {
    logger.error(`[EURUSD-FETCH] Invalid response structure`);
    throw new Error('Invalid response from Yahoo Finance for EURUSD=X');
  }

  const timestamps = result.timestamp;
  const indicators = result.indicators.quote[0];
  const ratesMap = {};

  logger.info(`[EURUSD-FETCH] Total EURUSD data points received: ${timestamps.length}`);

  for (let i = 0; i < timestamps.length; i++) {
    const timestamp = timestamps[i];
    const close = parseFloat(indicators.close[i]);

    if (!isNaN(close)) {
      const date = new Date(timestamp * 1000).toISOString().split('T')[0]; // YYYY-MM-DD
      ratesMap[date] = close;
    }
  }

  logger.info(`[EURUSD-FETCH] Successfully fetched ${Object.keys(ratesMap).length} EURUSD rates`);
  
  // Log first and last rates for verification
  const dates = Object.keys(ratesMap).sort();
  if (dates.length > 0) {
    logger.info(`[EURUSD-FETCH] First rate: ${dates[0]} = ${ratesMap[dates[0]]}`);
    logger.info(`[EURUSD-FETCH] Last rate: ${dates[dates.length - 1]} = ${ratesMap[dates[dates.length - 1]]}`);
  }

  return ratesMap;
}

/**
 * Internal function to fetch data from Yahoo Finance for a specific symbol
 * Downloads ALL available candles for the specified period without truncation
 * 
 * CRITICAL IMPLEMENTATION NOTES:
 * - Uses raw OHLC values (indicators.close) NOT adjusted close
 * - Yahoo Finance API automatically adjusts all OHLC for stock splits
 * - Example: GOOGL 20-for-1 split in July 2022 is already handled by API
 * - Pre-split prices (April 2022) are ~$110-115, post-split (March 2026) are ~$300
 * - Adjusted close is provided separately for reference but NOT used in calculations
 * - Data integrity validation ensures High >= max(Open, Close) and Low <= min(Open, Close)
 * - NO TRUNCATION: All available candles are returned for the specified period
 * 
 * @param {string} symbol - Stock symbol to fetch
 * @param {string} period - Time period
 * @param {string} interval - Candle interval
 * @returns {Promise<Array>} - Array of OHLCV candles with adjustedClose
 * @private
 */
async function fetchYahooFinanceDataInternal(symbol, period, interval = '1d') {
  const symbolUpper = symbol.toUpperCase();
  const now = Math.floor(Date.now() / 1000);
  const periodSeconds = getPeriodSeconds(period);
  const startTime = now - periodSeconds;

  logger.info(`[YAHOO-FETCH] Called with: symbol=${symbolUpper}, period='${period}', interval='${interval}'`);
  logger.info(`[YAHOO-FETCH] Period '${period}' converted to ${periodSeconds} seconds`);
  logger.info(`[YAHOO-FETCH] Time range: startTime=${startTime} (${new Date(startTime * 1000).toISOString()}), endTime=${now} (${new Date(now * 1000).toISOString()})`);

  // Endpoint Chart v8 (JSON)
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbolUpper}?period1=${startTime}&period2=${now}&interval=${interval}`;

  logger.info(`[YAHOO-FETCH] Requesting URL: ${url}`);

  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Origin': 'https://finance.yahoo.com',
      'Referer': 'https://finance.yahoo.com/'
    },
  });

  logger.info(`[YAHOO-FETCH] Response status: ${response.status} ${response.statusText}`);

  if (!response.ok) {
    logger.error(`[YAHOO-FETCH] API error: ${response.status} ${response.statusText}`);
    throw new Error(`Yahoo Finance API error: ${response.status} ${response.statusText}`);
  }

  const json = await response.json();
  
  // Validate Yahoo Finance response structure
  const result = json.chart?.result?.[0];
  if (!result || !result.timestamp) {
    logger.error(`[YAHOO-FETCH] Invalid response structure for symbol: ${symbolUpper}`);
    logger.error(`[YAHOO-FETCH] Full response: ${JSON.stringify(json, null, 2)}`);
    throw new Error(`Invalid response from Yahoo Finance for symbol: ${symbolUpper}`);
  }

  // Extract metadata
  const currency = result.meta?.currency || 'N/A';
  const exchange = result.meta?.exchangeName || 'N/A';
  const regularMarketPrice = result.meta?.regularMarketPrice || 'N/A';
  
  logger.info(`[YAHOO-FETCH] Currency: ${currency}`);
  logger.info(`[YAHOO-FETCH] Exchange: ${exchange}`);
  logger.info(`[YAHOO-FETCH] Regular Market Price: ${regularMarketPrice}`);

  const timestamps = result.timestamp;
  const indicators = result.indicators.quote[0];
  const adjCloseData = result.indicators.adjclose?.[0]?.adjclose || [];

  logger.info(`[YAHOO-FETCH] Total timestamps received from API: ${timestamps.length}`);

  const data = [];
  let skippedCount = 0;

  for (let i = 0; i < timestamps.length; i++) {
    // CRITICAL: Use raw OHLC values (indicators.close) NOT adjusted close
    // Yahoo Finance API automatically adjusts all OHLC for stock splits
    // Example: GOOGL 20-for-1 split in July 2022 is already handled
    // Pre-split prices (April 2022): ~$110-115
    // Post-split prices (March 2026): ~$300
    
    let open = parseFloat(indicators.open[i]);
    let high = parseFloat(indicators.high[i]);
    let low = parseFloat(indicators.low[i]);
    let close = parseFloat(indicators.close[i]);
    let volume = parseInt(indicators.volume[i], 10);
    let adjustedClose = adjCloseData[i] ? parseFloat(adjCloseData[i]) : close;

    // Skip invalid or incomplete records
    if (isNaN(open) || isNaN(high) || isNaN(low) || isNaN(close) || isNaN(volume)) {
      logger.warn(`[YAHOO-FETCH] Skipping invalid candle at index ${i}: O=${open} H=${high} L=${low} C=${close} V=${volume}`);
      skippedCount++;
      continue;
    }

    // DATA INTEGRITY VALIDATION
    // Ensure High is the highest and Low is the lowest
    // Sometimes API glitches return inverted or slightly off values
    const maxOC = Math.max(open, close);
    const minOC = Math.min(open, close);
    
    if (high < maxOC) {
      logger.warn(`[DATA-CORRECTION] High (${high}) was less than max(Open, Close) (${maxOC}) at index ${i}. Correcting.`);
      high = maxOC;
    }
    
    if (low > minOC) {
      logger.warn(`[DATA-CORRECTION] Low (${low}) was greater than min(Open, Close) (${minOC}) at index ${i}. Correcting.`);
      low = minOC;
    }

    // Convert timestamp to milliseconds for JavaScript
    const timestamp = timestamps[i] * 1000;
    const date = new Date(timestamp).toISOString().split('T')[0]; // YYYY-MM-DD format

    data.push({
      timestamp,
      date,
      open,
      high,
      low,
      close,
      volume,
      adjustedClose,
    });
  }

  // Sort by timestamp ascending
  data.sort((a, b) => a.timestamp - b.timestamp);

  logger.info(`[YAHOO-FETCH] Successfully fetched and validated ${data.length} candles for ${symbolUpper} (skipped ${skippedCount} invalid records)`);
  
  // Calculate date range
  if (data.length > 0) {
    const firstDate = data[0].date;
    const lastDate = data[data.length - 1].date;
    logger.info(`[YAHOO-FETCH] Date range: ${firstDate} to ${lastDate}`);
    logger.info(`[YAHOO-FETCH] Downloaded ${data.length} candles for ${symbolUpper} from ${firstDate} to ${lastDate}`);
  }
  
  // Log first 3 and last 3 candles for verification
  if (data.length > 0) {
    logger.info(`[YAHOO-FETCH] First candle: ${data[0].date} - O:${data[0].open} H:${data[0].high} L:${data[0].low} C:${data[0].close} AC:${data[0].adjustedClose}`);
    if (data.length > 1) {
      logger.info(`[YAHOO-FETCH] Second candle: ${data[1].date} - O:${data[1].open} H:${data[1].high} L:${data[1].low} C:${data[1].close} AC:${data[1].adjustedClose}`);
    }
    if (data.length > 2) {
      logger.info(`[YAHOO-FETCH] Third candle: ${data[2].date} - O:${data[2].open} H:${data[2].high} L:${data[2].low} C:${data[2].close} AC:${data[2].adjustedClose}`);
    }
    if (data.length > 3) {
      logger.info(`[YAHOO-FETCH] Last candle: ${data[data.length - 1].date} - O:${data[data.length - 1].open} H:${data[data.length - 1].high} L:${data[data.length - 1].low} C:${data[data.length - 1].close} AC:${data[data.length - 1].adjustedClose}`);
    }
  }

  return data;
}

/**
 * Fetch raw Yahoo Finance response for debugging
 * @param {string} symbol - Stock symbol (e.g., 'AAPL')
 * @param {string} period - Time period (e.g., '1y', '6m', '2m')
 * @param {string} interval - Candle interval (e.g., '1d', '1h', '15m', '5m')
 * @returns {Promise<Object>} - Raw Yahoo Finance API response
 */
export async function fetchYahooFinanceRawResponse(symbol, period, interval = '1d') {
  const symbolUpper = symbol.toUpperCase();
  const now = Math.floor(Date.now() / 1000);
  const periodSeconds = getPeriodSeconds(period);
  const startTime = now - periodSeconds;

  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${symbolUpper}?period1=${startTime}&period2=${now}&interval=${interval}`;

  logger.info(`[YAHOO-RAW-DEBUG] Fetching raw response from: ${url}`);

  const response = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
      'Accept': 'application/json, text/plain, */*',
      'Accept-Language': 'en-US,en;q=0.9',
      'Origin': 'https://finance.yahoo.com',
      'Referer': 'https://finance.yahoo.com/'
    },
  });

  if (!response.ok) {
    throw new Error(`Yahoo Finance API error: ${response.status} ${response.statusText}`);
  }

  const json = await response.json();
  return json;
}
