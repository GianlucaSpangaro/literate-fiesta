import { Router } from 'express';
import healthCheck from './health-check.js';
import technicalAnalysisRouter from './technical-analysis.js';

const router = Router();

export default () => {
    router.get('/health', healthCheck);
    router.use('/technical-analysis', technicalAnalysisRouter);

    return router;
};
