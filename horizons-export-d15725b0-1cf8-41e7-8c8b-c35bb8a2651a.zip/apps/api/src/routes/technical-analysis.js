import express from 'express';
import logger from '../utils/logger.js';
import { calculateSMA, calculateBollingerBands, calculateRSI, calculateMACD, calculateSAR, calculateStochastic } from '../utils/technical-indicators.js';
import { fetchYahooFinanceData, fetchYahooFinanceRawResponse, fetchEURUSDRates } from '../utils/yahoo-finance.js';
import { getFromCache, setInCache } from '../utils/cache.js';

const router = express.Router();

const VALID_PERIODS = ['1m', '3m', '6m', '1y', '2y', '5y', '10y'];
const VALID_TIMEFRAMES = ['5m', '15m', '30m', '1h', '1d', '1w', '1mo'];

// Map timeframe to Yahoo Finance interval parameter
const TIMEFRAME_TO_INTERVAL = {
  '5m': '5m',
  '15m': '15m',
  '30m': '30m',
  '1h': '1h',
  '1d': '1d',
  '1w': '1wk',
  '1mo': '1mo',
};

/**
 * Parse and validate MA200 parameters from query string
 * @param {Object} query - Express req.query object
 * @returns {Object} - Validated MA200 parameters with defaults
 */
function parseMA200Params(query) {
  const params = {
    period: 200,
    type: 'sma',
  };

  if (query.ma200Period !== undefined) {
    const val = parseInt(query.ma200Period, 10);
    if (isNaN(val) || val < 2 || val > 500) {
      throw new Error('ma200Period must be an integer between 2 and 500');
    }
    params.period = val;
  }

  if (query.ma200Type !== undefined) {
    const val = String(query.ma200Type).toLowerCase().trim();
    if (!['sma', 'ema'].includes(val)) {
      throw new Error('ma200Type must be either "sma" or "ema"');
    }
    params.type = val;
  }

  return params;
}

/**
 * Parse and validate oscillator parameters from query string
 * @param {Object} query - Express req.query object
 * @returns {Object} - Validated parameters with defaults
 */
function parseOscillatorParams(query) {
  const params = {
    rsiPeriod: 14,
    rsiOverbought: 70,
    rsiOversold: 30,
    macdFastEMA: 12,
    macdSlowEMA: 26,
    macdSignalLine: 9,
    bbPeriod: 20,
    bbStdDev: 2,
    stochasticKPeriod: 14,
    stochasticDPeriod: 3,
    stochasticOverbought: 80,
    stochasticOversold: 20,
  };

  if (query.rsiPeriod !== undefined) {
    const val = parseInt(query.rsiPeriod, 10);
    if (isNaN(val) || val < 2 || val > 100) throw new Error('rsiPeriod must be an integer between 2 and 100');
    params.rsiPeriod = val;
  }

  if (query.rsiOverbought !== undefined) {
    const val = parseInt(query.rsiOverbought, 10);
    if (isNaN(val) || val < 50 || val > 100) throw new Error('rsiOverbought must be an integer between 50 and 100');
    params.rsiOverbought = val;
  }

  if (query.rsiOversold !== undefined) {
    const val = parseInt(query.rsiOversold, 10);
    if (isNaN(val) || val < 0 || val > 50) throw new Error('rsiOversold must be an integer between 0 and 50');
    params.rsiOversold = val;
  }

  if (params.rsiOverbought <= params.rsiOversold) {
    throw new Error('rsiOverbought must be greater than rsiOversold');
  }

  if (query.macdFastEMA !== undefined) {
    const val = parseInt(query.macdFastEMA, 10);
    if (isNaN(val) || val < 2 || val > 50) throw new Error('macdFastEMA must be an integer between 2 and 50');
    params.macdFastEMA = val;
  }

  if (query.macdSlowEMA !== undefined) {
    const val = parseInt(query.macdSlowEMA, 10);
    if (isNaN(val) || val < 2 || val > 200) throw new Error('macdSlowEMA must be an integer between 2 and 200');
    params.macdSlowEMA = val;
  }

  if (query.macdSignalLine !== undefined) {
    const val = parseInt(query.macdSignalLine, 10);
    if (isNaN(val) || val < 2 || val > 50) throw new Error('macdSignalLine must be an integer between 2 and 50');
    params.macdSignalLine = val;
  }

  if (params.macdFastEMA >= params.macdSlowEMA) {
    throw new Error('macdFastEMA must be less than macdSlowEMA');
  }

  if (query.bbPeriod !== undefined) {
    const val = parseInt(query.bbPeriod, 10);
    if (isNaN(val) || val < 2 || val > 200) throw new Error('bbPeriod must be an integer between 2 and 200');
    params.bbPeriod = val;
  }

  if (query.bbStdDev !== undefined) {
    const val = parseFloat(query.bbStdDev);
    if (isNaN(val) || val < 0.5 || val > 5) throw new Error('bbStdDev must be a number between 0.5 and 5');
    params.bbStdDev = val;
  }

  if (query.stochasticKPeriod !== undefined) {
    const val = parseInt(query.stochasticKPeriod, 10);
    if (isNaN(val) || val < 2 || val > 100) throw new Error('stochasticKPeriod must be an integer between 2 and 100');
    params.stochasticKPeriod = val;
  }

  if (query.stochasticDPeriod !== undefined) {
    const val = parseInt(query.stochasticDPeriod, 10);
    if (isNaN(val) || val < 1 || val > 20) throw new Error('stochasticDPeriod must be an integer between 1 and 20');
    params.stochasticDPeriod = val;
  }

  if (query.stochasticOverbought !== undefined) {
    const val = parseInt(query.stochasticOverbought, 10);
    if (isNaN(val) || val < 50 || val > 100) throw new Error('stochasticOverbought must be an integer between 50 and 100');
    params.stochasticOverbought = val;
  }

  if (query.stochasticOversold !== undefined) {
    const val = parseInt(query.stochasticOversold, 10);
    if (isNaN(val) || val < 0 || val > 50) throw new Error('stochasticOversold must be an integer between 0 and 50');
    params.stochasticOversold = val;
  }

  if (params.stochasticOverbought <= params.stochasticOversold) {
    throw new Error('stochasticOverbought must be greater than stochasticOversold');
  }

  return params;
}

/**
 * Validate and adjust period based on timeframe limitations
 */
function validatePeriodForTimeframe(period, timeframe) {
  if (['5m', '15m', '30m'].includes(timeframe)) {
    if (!['1m', '2m'].includes(period)) {
      return '2m';
    }
  }

  if (timeframe === '1h') {
    if (['5y', '10y'].includes(period)) {
      return '2y';
    }
  }

  return period;
}

/**
 * Apply USD to EUR conversion to historical data
 * @param {Array} data - Array of OHLCV candles in USD
 * @param {Object} eurUsdRates - Map of date (YYYY-MM-DD) to EURUSD rate
 * @returns {Array} - Array of candles converted to EUR
 */
function convertToEUR(data, eurUsdRates) {
  logger.info(`[EUR-CONVERSION] Converting ${data.length} candles from USD to EUR`);
  
  const converted = data.map((candle, index) => {
    const date = candle.date; // YYYY-MM-DD format
    const rate = eurUsdRates[date];
    
    if (!rate) {
      logger.warn(`[EUR-CONVERSION] No EURUSD rate found for date ${date} (index ${index}). Using previous rate or skipping.`);
      // Try to find the closest previous rate
      const dates = Object.keys(eurUsdRates).sort();
      let closestRate = null;
      for (const d of dates) {
        if (d <= date) {
          closestRate = eurUsdRates[d];
        } else {
          break;
        }
      }
      
      if (!closestRate) {
        logger.error(`[EUR-CONVERSION] Could not find any EURUSD rate for date ${date}`);
        throw new Error(`No EURUSD rate available for date ${date}`);
      }
      
      logger.info(`[EUR-CONVERSION] Using closest rate from ${dates[dates.length - 1]} for date ${date}`);
      return {
        ...candle,
        open: parseFloat((candle.open / closestRate).toFixed(2)),
        high: parseFloat((candle.high / closestRate).toFixed(2)),
        low: parseFloat((candle.low / closestRate).toFixed(2)),
        close: parseFloat((candle.close / closestRate).toFixed(2)),
        adjustedClose: parseFloat((candle.adjustedClose / closestRate).toFixed(2)),
        eurUsdRate: parseFloat(closestRate.toFixed(4)),
      };
    }
    
    return {
      ...candle,
      open: parseFloat((candle.open / rate).toFixed(2)),
      high: parseFloat((candle.high / rate).toFixed(2)),
      low: parseFloat((candle.low / rate).toFixed(2)),
      close: parseFloat((candle.close / rate).toFixed(2)),
      adjustedClose: parseFloat((candle.adjustedClose / rate).toFixed(2)),
      eurUsdRate: parseFloat(rate.toFixed(4)),
    };
  });
  
  logger.info(`[EUR-CONVERSION] Successfully converted ${converted.length} candles to EUR`);
  
  // Log first and last converted candles for verification
  if (converted.length > 0) {
    logger.info(`[EUR-CONVERSION] First candle: ${converted[0].date} - O:€${converted[0].open} H:€${converted[0].high} L:€${converted[0].low} C:€${converted[0].close} (Rate: ${converted[0].eurUsdRate})`);
    logger.info(`[EUR-CONVERSION] Last candle: ${converted[converted.length - 1].date} - O:€${converted[converted.length - 1].open} H:€${converted[converted.length - 1].high} L:€${converted[converted.length - 1].low} C:€${converted[converted.length - 1].close} (Rate: ${converted[converted.length - 1].eurUsdRate})`);
  }
  
  return converted;
}

router.get('/debug/raw', async (req, res) => {
  const { symbol, period = '1y', timeframe = '1d' } = req.query;

  if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
    return res.status(400).json({ error: 'Symbol parameter is required' });
  }

  const validatedPeriod = validatePeriodForTimeframe(period, timeframe);
  const yahooInterval = TIMEFRAME_TO_INTERVAL[timeframe];

  const rawResponse = await fetchYahooFinanceRawResponse(symbol, validatedPeriod, yahooInterval);

  const result = rawResponse.chart?.result?.[0];
  if (!result) {
    return res.json({ error: 'Invalid response structure', rawResponse });
  }

  const indicators = result.indicators.quote[0];
  const timestamps = result.timestamp;

  res.json({
    metadata: {
      symbol,
      period,
      timeframe,
      validatedPeriod,
      yahooInterval,
      totalCandles: timestamps.length,
    },
    first5Candles: timestamps.slice(0, 5).map((ts, i) => ({
      index: i,
      timestamp: ts,
      open: indicators.open[i],
      high: indicators.high[i],
      low: indicators.low[i],
      close: indicators.close[i],
      volume: indicators.volume[i],
    })),
  });
});

router.get('/', async (req, res) => {
  const { symbol, period = '1y', timeframe = '1d' } = req.query;

  if (!symbol || typeof symbol !== 'string' || symbol.trim() === '') {
    return res.status(400).json({ error: 'Symbol parameter is required' });
  }

  if (!VALID_PERIODS.includes(period)) {
    return res.status(400).json({ error: `Invalid period. Must be one of: ${VALID_PERIODS.join(', ')}` });
  }

  if (!VALID_TIMEFRAMES.includes(timeframe)) {
    return res.status(400).json({ error: `Invalid timeframe. Must be one of: ${VALID_TIMEFRAMES.join(', ')}` });
  }

  let ma200Params;
  try {
    ma200Params = parseMA200Params(req.query);
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }

  let oscillatorParams;
  try {
    oscillatorParams = parseOscillatorParams(req.query);
  } catch (error) {
    return res.status(400).json({ error: error.message });
  }

  const validatedPeriod = validatePeriodForTimeframe(period, timeframe);
  const cacheKey = `${symbol.toUpperCase()}_${validatedPeriod}_${timeframe}_${JSON.stringify(oscillatorParams)}_${JSON.stringify(ma200Params)}`;
  const cachedData = getFromCache(cacheKey);

  if (cachedData) {
    logger.info(`[TECHNICAL-ANALYSIS] Returning cached data for ${symbol}`);
    return res.json(cachedData);
  }

  const yahooInterval = TIMEFRAME_TO_INTERVAL[timeframe];
  
  // TASK 1: Fetch real historical data from Yahoo Finance
  // This will throw an Error if fetch fails (not ok response)
  // The error middleware will catch it and return 500
  const historicalDataUSD = await fetchYahooFinanceData(symbol, validatedPeriod, yahooInterval);

  if (!historicalDataUSD || historicalDataUSD.length === 0) {
    throw new Error(`No data available for symbol: ${symbol}`);
  }

  // Log data integrity validation
  logger.info(`[TECHNICAL-ANALYSIS] Verifying first 5 candles for ${symbol}`);
  for (let i = 0; i < Math.min(5, historicalDataUSD.length); i++) {
    const c = historicalDataUSD[i];
    const maxOC = Math.max(c.open, c.close);
    const minOC = Math.min(c.open, c.close);
    const isValid = c.high >= maxOC && c.low <= minOC;
    
    logger.info(`[CANDLE-CHECK] Date: ${c.date}, Open: ${c.open}, Close: ${c.close}, High: ${c.high}, Low: ${c.low}, AdjClose: ${c.adjustedClose}, Valid: ${isValid}`);
    
    if (!isValid) {
      logger.warn(`[CANDLE-CHECK-WARNING] Invalid candle detected at index ${i}. High/Low bounds violated.`);
    }
  }

  // TASK 2: Fetch EURUSD exchange rates for the same date range
  const now = Math.floor(Date.now() / 1000);
  const periodSeconds = validatedPeriod === '1m' ? 30 * 24 * 60 * 60 :
                        validatedPeriod === '2m' ? 60 * 24 * 60 * 60 :
                        validatedPeriod === '3m' ? 90 * 24 * 60 * 60 :
                        validatedPeriod === '6m' ? 180 * 24 * 60 * 60 :
                        validatedPeriod === '1y' ? 365 * 24 * 60 * 60 :
                        validatedPeriod === '2y' ? 2 * 365 * 24 * 60 * 60 :
                        validatedPeriod === '5y' ? 5 * 365 * 24 * 60 * 60 :
                        10 * 365 * 24 * 60 * 60;
  const startTime = now - periodSeconds;
  
  const eurUsdRates = await fetchEURUSDRates(startTime, now);

  // TASK 3: Convert historical data from USD to EUR using daily exchange rates
  const historicalDataEUR = convertToEUR(historicalDataUSD, eurUsdRates);

  const aggregatedData = aggregateByTimeframe(historicalDataEUR, timeframe);

  let ma200;
  if (ma200Params.type === 'ema') {
    ma200 = calculateEMA(aggregatedData, ma200Params.period);
  } else {
    ma200 = calculateSMA(aggregatedData, ma200Params.period);
  }

  const bollingerBands = calculateBollingerBands(aggregatedData, oscillatorParams.bbPeriod, oscillatorParams.bbStdDev);
  const rsi = calculateRSI(aggregatedData, oscillatorParams.rsiPeriod);
  const macd = calculateMACD(aggregatedData, oscillatorParams.macdFastEMA, oscillatorParams.macdSlowEMA, oscillatorParams.macdSignalLine);
  
  // TASK 4: Calculate Parabolic SAR with proper initialization and continuous tracking
  const sar = calculateSAR(aggregatedData, 0.02, 0.2);
  
  const stochastic = calculateStochastic(aggregatedData, oscillatorParams.stochasticKPeriod, oscillatorParams.stochasticDPeriod);

  const candlesticks = aggregatedData.map(candle => ({
    timestamp: candle.timestamp,
    date: candle.date,
    open: candle.open,
    high: candle.high,
    low: candle.low,
    close: candle.close,
    volume: candle.volume,
    adjustedClose: candle.adjustedClose,
    eurUsdRate: candle.eurUsdRate,
  }));

  const volumes = aggregatedData.map(candle => ({
    timestamp: candle.timestamp,
    volume: candle.volume,
  }));

  const response = {
    candlesticks,
    volumes,
    rsi,
    macd,
    ma200,
    bollingerBands,
    sar,
    stochastic,
    oscillatorParams,
    ma200Params,
    currency: 'EUR',
    conversionInfo: {
      originalCurrency: 'USD',
      convertedCurrency: 'EUR',
      conversionMethod: 'Daily EURUSD exchange rates from Yahoo Finance',
      formula: 'Price_EUR = Price_USD ÷ EURUSD_Rate_of_that_day',
    },
  };

  setInCache(cacheKey, response, 3600);
  res.json(response);
});

function aggregateByTimeframe(data, timeframe) {
  if (timeframe === '1d') {
    return data;
  }

  const timeframeMs = getTimeframeMs(timeframe);
  const aggregated = [];
  let currentBucket = null;
  let bucketData = null;

  for (let i = 0; i < data.length; i++) {
    const candle = data[i];
    const timestamp = candle.timestamp;
    const bucketStart = Math.floor(timestamp / timeframeMs) * timeframeMs;

    if (currentBucket !== bucketStart) {
      if (bucketData) {
        aggregated.push({
          timestamp: currentBucket,
          date: new Date(currentBucket).toISOString().split('T')[0],
          open: bucketData.open,
          high: bucketData.high,
          low: bucketData.low,
          close: bucketData.close,
          volume: bucketData.volume,
          adjustedClose: bucketData.adjustedClose,
          eurUsdRate: bucketData.eurUsdRate,
        });
      }

      currentBucket = bucketStart;
      bucketData = {
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
        volume: candle.volume,
        adjustedClose: candle.adjustedClose,
        eurUsdRate: candle.eurUsdRate,
      };
    } else if (bucketData) {
      bucketData.high = Math.max(bucketData.high, candle.high);
      bucketData.low = Math.min(bucketData.low, candle.low);
      bucketData.close = candle.close;
      bucketData.volume += candle.volume;
      bucketData.adjustedClose = candle.adjustedClose;
      bucketData.eurUsdRate = candle.eurUsdRate;
    }
  }

  if (bucketData) {
    aggregated.push({
      timestamp: currentBucket,
      date: new Date(currentBucket).toISOString().split('T')[0],
      open: bucketData.open,
      high: bucketData.high,
      low: bucketData.low,
      close: bucketData.close,
      volume: bucketData.volume,
      adjustedClose: bucketData.adjustedClose,
      eurUsdRate: bucketData.eurUsdRate,
    });
  }

  return aggregated;
}

function getTimeframeMs(timeframe) {
  const timeframeMap = {
    '5m': 5 * 60 * 1000,
    '15m': 15 * 60 * 1000,
    '30m': 30 * 60 * 1000,
    '1h': 60 * 60 * 1000,
    '1d': 24 * 60 * 60 * 1000,
    '1w': 7 * 24 * 60 * 60 * 1000,
    '1mo': 30 * 24 * 60 * 60 * 1000,
  };
  return timeframeMap[timeframe] || 24 * 60 * 60 * 1000;
}

function calculateEMA(data, period) {
  const result = [];
  const multiplier = 2 / (period + 1);
  let ema = null;

  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      continue;
    }

    if (ema === null) {
      const slice = data.slice(0, period);
      ema = slice.reduce((sum, candle) => sum + candle.close, 0) / period;
    } else {
      ema = (data[i].close - ema) * multiplier + ema;
    }

    result.push({
      timestamp: data[i].timestamp,
      value: parseFloat(ema.toFixed(2)),
    });
  }

  return result;
}

export default router;
